// API Configuration and Base Service
const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

// Check if we're in development and adjust protocol if needed
const getApiUrl = () => {
  if (import.meta.env.DEV && window.location.protocol === 'https:') {
    // In development, if frontend is HTTPS, try HTTPS backend first, fallback to HTTP
    return API_BASE_URL.replace('http://', 'https://');
  }
  return API_BASE_URL;
};

class ApiService {
  constructor() {
    this.baseURL = getApiUrl();
    this.token = localStorage.getItem('securosync_token');
  }

  // Set auth token
  setToken(token) {
    this.token = token;
    if (token) {
      localStorage.setItem('securosync_token', token);
    } else {
      localStorage.removeItem('securosync_token');
    }
  }

  // Get auth headers
  getHeaders() {
    const headers = {
      'Content-Type': 'application/json',
    };

    if (this.token) {
      headers.Authorization = `Bearer ${this.token}`;
    }

    return headers;
  }

  // Generic request method
  async request(endpoint, options = {}) {
    const url = `${this.baseURL}${endpoint}`;
    const config = {
      headers: this.getHeaders(),
      ...options,
    };

    try {
      const response = await fetch(url, config);
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'API request failed');
      }

      return data;
    } catch (error) {
      console.error('API Request Error:', error);
      throw error;
    }
  }

  // GET request
  async get(endpoint) {
    return this.request(endpoint, { method: 'GET' });
  }

  // POST request
  async post(endpoint, data) {
    return this.request(endpoint, {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  // PUT request
  async put(endpoint, data) {
    return this.request(endpoint, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  }

  // DELETE request
  async delete(endpoint) {
    return this.request(endpoint, { method: 'DELETE' });
  }
}

// Create singleton instance
const apiService = new ApiService();

// Authentication API calls
export const authAPI = {
  login: async (email, password) => {
    const response = await apiService.post('/auth/login', { email, password });
    if (response.success && response.token) {
      apiService.setToken(response.token);
    }
    return response;
  },

  register: async (userData) => {
    const response = await apiService.post('/auth/register', userData);
    if (response.success && response.token) {
      apiService.setToken(response.token);
    }
    return response;
  },

  logout: async () => {
    try {
      await apiService.get('/auth/logout');
    } finally {
      apiService.setToken(null);
    }
  },

  getMe: async () => {
    return apiService.get('/auth/me');
  },

  updateProfile: async (userData) => {
    return apiService.put('/auth/updatedetails', userData);
  },

  updatePassword: async (passwordData) => {
    return apiService.put('/auth/updatepassword', passwordData);
  }
};

// Dashboard API calls
export const dashboardAPI = {
  getOverview: async () => {
    return apiService.get('/dashboard/overview');
  },

  getComplianceHeatMap: async (framework = 'SOC2') => {
    return apiService.get(`/dashboard/compliance-heatmap?framework=${framework}`);
  },

  runAssessment: async (framework = 'SOC2') => {
    return apiService.post('/dashboard/run-assessment', { framework });
  }
};

// Audit Logs API calls
export const auditLogsAPI = {
  getLogs: async (params = {}) => {
    const queryString = new URLSearchParams(params).toString();
    return apiService.get(`/audit-logs?${queryString}`);
  },

  exportLogs: async (params = {}) => {
    const queryString = new URLSearchParams(params).toString();
    return apiService.get(`/audit-logs/export?${queryString}`);
  }
};

// Health check
export const healthAPI = {
  check: async () => {
    return apiService.get('/health');
  }
};

export default apiService;