import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Shield, Mail, User, Building, Target, CheckCircle, ArrowLeft, Send } from 'lucide-react';

export default function WishlistPage() {
  const [formData, setFormData] = useState({
    email: '',
    fullName: '',
    jobTitle: '',
    company: '',
    companySize: '',
    industry: '',
    complianceGoal: 'SOC2',
    currentChallenges: '',
    timeline: '',
    hearAboutUs: ''
  });
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    // Simulate API call to submit wishlist request
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setLoading(false);
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-teal-900 flex items-center justify-center px-4">
        <div className="w-full max-w-md">
          <div className="bg-white rounded-xl shadow-2xl p-6 md:p-8 text-center">
            <div className="w-12 h-12 md:w-16 md:h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4 md:mb-6">
              <CheckCircle className="h-6 w-6 md:h-8 md:w-8 text-green-600" />
            </div>
            <h1 className="text-xl md:text-2xl font-bold text-gray-900 mb-3 md:mb-4">You're on the list!</h1>
            <p className="text-gray-600 mb-4 md:mb-6 text-sm md:text-base">
              Thank you for your interest in SecuroSync. We've received your request and will review it shortly.
            </p>
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 md:p-4 mb-4 md:mb-6">
              <h3 className="font-semibold text-blue-900 mb-2 text-sm md:text-base">What happens next?</h3>
              <ul className="text-xs md:text-sm text-blue-800 space-y-1 text-left">
                <li>• Our team will review your application</li>
                <li>• We'll send you login credentials via email</li>
                <li>• You'll receive a welcome message with setup instructions</li>
                <li>• Expected response time: 24-48 hours</li>
              </ul>
            </div>
            <Link 
              to="/" 
              className="inline-flex items-center text-blue-600 hover:text-blue-800 font-medium text-sm md:text-base"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Home
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-teal-900">
      {/* Navigation */}
      <nav className="relative px-4 md:px-6 py-3 md:py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <Link 
            to="/" 
            className="flex items-center text-white hover:text-blue-300 transition-colors duration-200 bg-black bg-opacity-20 backdrop-blur-sm rounded-lg px-2 md:px-3 py-1 md:py-2"
          >
            <ArrowLeft className="h-4 w-4 md:h-5 md:w-5 mr-1 md:mr-2" />
            <span className="text-sm md:text-base">Back to Home</span>
          </Link>
          <div className="flex items-center space-x-1 md:space-x-2">
            <Shield className="h-6 w-6 md:h-8 md:w-8 text-blue-400" />
            <span className="text-lg md:text-2xl font-bold text-white">SecuroSync</span>
          </div>
          <Link 
            to="/login" 
            className="text-white hover:text-blue-300 transition-colors duration-200 text-sm md:text-base hidden sm:block"
          >
            Already have access? Login
          </Link>
          <Link 
            to="/login" 
            className="text-white hover:text-blue-300 transition-colors duration-200 text-xs sm:hidden"
          >
            Login
          </Link>
        </div>
      </nav>

      {/* Main Content */}
      <div className="px-4 md:px-6 py-4 md:py-8">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-6 md:mb-8">
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-3 md:mb-4">
              Join the SecuroSync 
              <span className="text-blue-400"> Early Access</span>
            </h1>
            <p className="text-lg md:text-xl text-blue-100 mb-4 md:mb-6 max-w-3xl mx-auto">
              Be among the first to experience AI-powered compliance automation. 
              We're currently in MVP phase and carefully selecting early adopters.
            </p>
            <div className="inline-flex items-center px-3 md:px-4 py-2 bg-blue-800 bg-opacity-50 rounded-full text-blue-200 text-sm font-medium">
              <Target className="h-4 w-4 mr-2" />
              Limited Early Access Program
            </div>
          </div>

          {/* Form */}
          <div className="bg-white rounded-xl shadow-2xl p-4 md:p-6 lg:p-8">
            <form onSubmit={handleSubmit} className="space-y-6 md:space-y-8">
              {/* Contact Information */}
              <div>
                <h2 className="text-lg md:text-xl font-semibold text-gray-900 mb-3 md:mb-4 flex items-center">
                  <User className="h-5 w-5 mr-2 text-blue-600" />
                  Contact Information
                </h2>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Full Name *
                    </label>
                    <input
                      name="fullName"
                      type="text"
                      value={formData.fullName}
                      onChange={handleChange}
                      required
                      className="w-full px-3 md:px-4 py-2 md:py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm md:text-base"
                      placeholder="Enter your full name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Email Address *
                    </label>
                    <input
                      name="email"
                      type="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      className="w-full px-3 md:px-4 py-2 md:py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm md:text-base"
                      placeholder="Enter your work email"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Job Title *
                    </label>
                    <select
                      name="jobTitle"
                      value={formData.jobTitle}
                      onChange={handleChange}
                      required
                      className="w-full px-3 md:px-4 py-2 md:py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm md:text-base"
                    >
                      <option value="">Select your role</option>
                      <option value="CEO/Founder">CEO/Founder</option>
                      <option value="CTO">CTO</option>
                      <option value="CISO">CISO</option>
                      <option value="Security Engineer">Security Engineer</option>
                      <option value="DevOps Engineer">DevOps Engineer</option>
                      <option value="Compliance Manager">Compliance Manager</option>
                      <option value="IT Manager">IT Manager</option>
                      <option value="Developer">Developer</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Company Name *
                    </label>
                    <input
                      name="company"
                      type="text"
                      value={formData.company}
                      onChange={handleChange}
                      required
                      className="w-full px-3 md:px-4 py-2 md:py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm md:text-base"
                      placeholder="Enter your company name"
                    />
                  </div>
                </div>
              </div>

              {/* Company Information */}
              <div>
                <h2 className="text-lg md:text-xl font-semibold text-gray-900 mb-3 md:mb-4 flex items-center">
                  <Building className="h-5 w-5 mr-2 text-blue-600" />
                  Company Information
                </h2>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Company Size *
                    </label>
                    <select
                      name="companySize"
                      value={formData.companySize}
                      onChange={handleChange}
                      required
                      className="w-full px-3 md:px-4 py-2 md:py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm md:text-base"
                    >
                      <option value="">Select company size</option>
                      <option value="1-10">1-10 employees</option>
                      <option value="11-50">11-50 employees</option>
                      <option value="51-200">51-200 employees</option>
                      <option value="201-500">201-500 employees</option>
                      <option value="500+">500+ employees</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Industry *
                    </label>
                    <select
                      name="industry"
                      value={formData.industry}
                      onChange={handleChange}
                      required
                      className="w-full px-3 md:px-4 py-2 md:py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm md:text-base"
                    >
                      <option value="">Select industry</option>
                      <option value="Technology">Technology/Software</option>
                      <option value="Healthcare">Healthcare</option>
                      <option value="Financial Services">Financial Services</option>
                      <option value="E-commerce">E-commerce</option>
                      <option value="Manufacturing">Manufacturing</option>
                      <option value="Education">Education</option>
                      <option value="Government">Government</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Compliance Needs */}
              <div>
                <h2 className="text-lg md:text-xl font-semibold text-gray-900 mb-3 md:mb-4 flex items-center">
                  <Target className="h-5 w-5 mr-2 text-blue-600" />
                  Compliance Requirements
                </h2>
                <div className="space-y-4 md:space-y-6">
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Primary Compliance Goal *
                      </label>
                      <select
                        name="complianceGoal"
                        value={formData.complianceGoal}
                        onChange={handleChange}
                        required
                        className="w-full px-3 md:px-4 py-2 md:py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm md:text-base"
                      >
                        <option value="SOC2">SOC 2 Type I/II</option>
                        <option value="ISO27001">ISO 27001</option>
                        <option value="HIPAA">HIPAA</option>
                        <option value="GDPR">GDPR</option>
                        <option value="Multiple">Multiple Standards</option>
                        <option value="Not Sure">Not Sure Yet</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Timeline for Compliance
                      </label>
                      <select
                        name="timeline"
                        value={formData.timeline}
                        onChange={handleChange}
                        className="w-full px-3 md:px-4 py-2 md:py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm md:text-base"
                      >
                        <option value="">Select timeline</option>
                        <option value="Immediate">Immediate (0-3 months)</option>
                        <option value="Short-term">Short-term (3-6 months)</option>
                        <option value="Medium-term">Medium-term (6-12 months)</option>
                        <option value="Long-term">Long-term (12+ months)</option>
                        <option value="Exploring">Just exploring options</option>
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Current Security/Compliance Challenges
                    </label>
                    <textarea
                      name="currentChallenges"
                      value={formData.currentChallenges}
                      onChange={handleChange}
                      rows={3}
                      className="w-full px-3 md:px-4 py-2 md:py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm md:text-base"
                      placeholder="Tell us about your current challenges with security compliance..."
                    />
                  </div>
                </div>
              </div>

              {/* Additional Information */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  How did you hear about us?
                </label>
                <select
                  name="hearAboutUs"
                  value={formData.hearAboutUs}
                  onChange={handleChange}
                  className="w-full px-3 md:px-4 py-2 md:py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm md:text-base"
                >
                  <option value="">Select source</option>
                  <option value="Search Engine">Search Engine</option>
                  <option value="Social Media">Social Media</option>
                  <option value="Referral">Referral from colleague</option>
                  <option value="Industry Event">Industry Event</option>
                  <option value="Blog/Article">Blog/Article</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              {/* Submit Button */}
              <div className="pt-4 md:pt-6 border-t border-gray-200">
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 md:py-4 px-4 md:px-6 rounded-lg font-semibold transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center text-sm md:text-base"
                >
                  {loading ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 md:h-5 md:w-5 border-b-2 border-white mr-2"></div>
                      Submitting Request...
                    </>
                  ) : (
                    <>
                      <Send className="h-4 w-4 md:h-5 md:w-5 mr-2" />
                      Request Early Access
                    </>
                  )}
                </button>
                <p className="text-xs md:text-sm text-gray-500 text-center mt-3">
                  We'll review your application and send you login credentials within 24-48 hours.
                </p>
              </div>
            </form>
          </div>

          {/* Benefits Section */}
          <div className="mt-8 md:mt-12 grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6">
            <div className="text-center text-white">
              <div className="w-10 h-10 md:w-12 md:h-12 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-3 md:mb-4">
                <Shield className="h-5 w-5 md:h-6 md:w-6" />
              </div>
              <h3 className="font-semibold mb-2 text-sm md:text-base">Early Access Benefits</h3>
              <p className="text-blue-200 text-xs md:text-sm">Get exclusive access to cutting-edge compliance automation</p>
            </div>
            <div className="text-center text-white">
              <div className="w-10 h-10 md:w-12 md:h-12 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-3 md:mb-4">
                <User className="h-5 w-5 md:h-6 md:w-6" />
              </div>
              <h3 className="font-semibold mb-2 text-sm md:text-base">Direct Founder Access</h3>
              <p className="text-blue-200 text-xs md:text-sm">Work directly with our founding team during MVP phase</p>
            </div>
            <div className="text-center text-white">
              <div className="w-10 h-10 md:w-12 md:h-12 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-3 md:mb-4">
                <Target className="h-5 w-5 md:h-6 md:w-6" />
              </div>
              <h3 className="font-semibold mb-2 text-sm md:text-base">Shape the Product</h3>
              <p className="text-blue-200 text-xs md:text-sm">Your feedback will directly influence our roadmap</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}