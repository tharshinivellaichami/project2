import React, { useState } from 'react';
import { 
  Cloud, 
  Github, 
  GitBranch, 
  Database, 
  Shield, 
  CheckCircle, 
  AlertCircle,
  Settings,
  Plus,
  ExternalLink,
  Loader,
  Search,
  Filter,
  Zap,
  Trash2,
  RefreshCw,
  Eye,
  ArrowLeft
} from 'lucide-react';
import { Link } from 'react-router-dom';
import SearchBar from '../components/SearchBar';
import Modal from '../components/Modal';
import { useToast } from '../hooks/useToast';

interface Integration {
  id: number;
  name: string;
  type: string;
  icon: any;
  status: 'connected' | 'available' | 'connecting' | 'error';
  description: string;
  lastSync: string | null;
  controls: number;
  issues: number;
  category: 'cloud' | 'scm' | 'database' | 'security';
  popular: boolean;
}

export default function Integrations() {
  const [integrations, setIntegrations] = useState<Integration[]>([
    {
      id: 1,
      name: 'Amazon Web Services',
      type: 'aws',
      icon: Cloud,
      status: 'connected',
      description: 'Monitor IAM, S3, CloudTrail, and security groups',
      lastSync: '2 minutes ago',
      controls: 23,
      issues: 5,
      category: 'cloud',
      popular: true
    },
    {
      id: 2,
      name: 'GitHub',
      type: 'github',
      icon: Github,
      status: 'connected',
      description: 'Repository security, access controls, and audit logs',
      lastSync: '5 minutes ago',
      controls: 12,
      issues: 2,
      category: 'scm',
      popular: true
    },
    {
      id: 3,
      name: 'GitLab',
      type: 'gitlab',
      icon: GitBranch,
      status: 'available',
      description: 'Source code security and compliance monitoring',
      lastSync: null,
      controls: 0,
      issues: 0,
      category: 'scm',
      popular: false
    },
    {
      id: 4,
      name: 'Microsoft Azure',
      type: 'azure',
      icon: Cloud,
      status: 'available',
      description: 'Azure Active Directory and resource monitoring',
      lastSync: null,
      controls: 0,
      issues: 0,
      category: 'cloud',
      popular: true
    },
    {
      id: 5,
      name: 'Google Cloud Platform',
      type: 'gcp',
      icon: Cloud,
      status: 'available',
      description: 'GCP IAM, storage, and security monitoring',
      lastSync: null,
      controls: 0,
      issues: 0,
      category: 'cloud',
      popular: true
    },
    {
      id: 6,
      name: 'Kubernetes',
      type: 'k8s',
      icon: Database,
      status: 'available',
      description: 'Container orchestration security monitoring',
      lastSync: null,
      controls: 0,
      issues: 0,
      category: 'cloud',
      popular: false
    },
    {
      id: 7,
      name: 'Okta',
      type: 'okta',
      icon: Shield,
      status: 'available',
      description: 'Identity and access management monitoring',
      lastSync: null,
      controls: 0,
      issues: 0,
      category: 'security',
      popular: true
    },
    {
      id: 8,
      name: 'MongoDB Atlas',
      type: 'mongodb',
      icon: Database,
      status: 'available',
      description: 'Database security and access monitoring',
      lastSync: null,
      controls: 0,
      issues: 0,
      category: 'database',
      popular: false
    }
  ]);

  const [showConnectionModal, setShowConnectionModal] = useState(false);
  const [selectedIntegration, setSelectedIntegration] = useState<Integration | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [refreshing, setRefreshing] = useState(false);
  const { showToast } = useToast();

  const categories = [
    { id: 'all', name: 'All Integrations', count: integrations.length },
    { id: 'cloud', name: 'Cloud Providers', count: integrations.filter(i => i.category === 'cloud').length },
    { id: 'scm', name: 'Source Control', count: integrations.filter(i => i.category === 'scm').length },
    { id: 'security', name: 'Security Tools', count: integrations.filter(i => i.category === 'security').length },
    { id: 'database', name: 'Databases', count: integrations.filter(i => i.category === 'database').length }
  ];

  const filteredIntegrations = integrations.filter(integration => {
    const matchesSearch = integration.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         integration.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || integration.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleConnect = (integration: Integration) => {
    setSelectedIntegration(integration);
    setShowConnectionModal(true);
  };

  const handleConnectionSubmit = () => {
    if (selectedIntegration) {
      // Update integration status to connecting
      setIntegrations(prev => prev.map(int => 
        int.id === selectedIntegration.id 
          ? { ...int, status: 'connecting' as const }
          : int
      ));

      showToast('success', `Connecting to ${selectedIntegration.name}...`);

      // Simulate connection process
      setTimeout(() => {
        setIntegrations(prev => prev.map(int => 
          int.id === selectedIntegration.id 
            ? { 
                ...int, 
                status: 'connected' as const,
                lastSync: 'Just now',
                controls: Math.floor(Math.random() * 20) + 5,
                issues: Math.floor(Math.random() * 5)
              }
            : int
        ));
        showToast('success', `Successfully connected to ${selectedIntegration.name}!`);
      }, 3000);
    }
    setShowConnectionModal(false);
    setSelectedIntegration(null);
  };

  const handleDisconnect = (integrationId: number) => {
    const integration = integrations.find(i => i.id === integrationId);
    setIntegrations(prev => prev.map(int => 
      int.id === integrationId 
        ? { 
            ...int, 
            status: 'available' as const,
            lastSync: null,
            controls: 0,
            issues: 0
          }
        : int
    ));
    if (integration) {
      showToast('success', `Disconnected from ${integration.name}`);
    }
  };

  const handleSync = async (integrationId: number) => {
    const integration = integrations.find(i => i.id === integrationId);
    if (integration) {
      showToast('info', `Syncing ${integration.name}...`);
      
      // Simulate sync process
      setTimeout(() => {
        setIntegrations(prev => prev.map(int => 
          int.id === integrationId 
            ? { ...int, lastSync: 'Just now' }
            : int
        ));
        showToast('success', `${integration.name} synced successfully!`);
      }, 2000);
    }
  };

  const handleRefreshAll = async () => {
    setRefreshing(true);
    showToast('info', 'Refreshing all integrations...');
    
    // Simulate refresh process
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    setRefreshing(false);
    showToast('success', 'All integrations refreshed successfully!');
  };

  const handleViewDetails = (integration: Integration) => {
    showToast('info', `Opening ${integration.name} details...`);
    // In a real app, this would navigate to a detailed view
  };

  const handleTestConnection = (integration: Integration) => {
    showToast('info', `Testing connection to ${integration.name}...`);
    
    setTimeout(() => {
      showToast('success', `Connection to ${integration.name} is healthy!`);
    }, 2000);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'connected':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'connecting':
        return <Loader className="h-5 w-5 text-blue-500 animate-spin" />;
      case 'error':
        return <AlertCircle className="h-5 w-5 text-red-500" />;
      default:
        return <Plus className="h-5 w-5 text-gray-400" />;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'connected':
        return 'Connected';
      case 'connecting':
        return 'Connecting...';
      case 'error':
        return 'Connection Error';
      default:
        return 'Available';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'connected':
        return 'text-green-600 bg-green-100';
      case 'connecting':
        return 'text-blue-600 bg-blue-100';
      case 'error':
        return 'text-red-600 bg-red-100';
      default:
        return 'text-gray-600 bg-gray-100';
    }
  };

  return (
    <div className="p-6">
      {/* Back Button */}
      <div className="mb-4">
        <Link 
          to="/dashboard" 
          className="flex items-center text-gray-600 hover:text-gray-900 transition-colors duration-200"
        >
          <ArrowLeft className="h-5 w-5 mr-2" />
          Back to Dashboard
        </Link>
      </div>

      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Infrastructure Integrations</h1>
            <p className="text-gray-600 mt-2">Connect your infrastructure to monitor compliance across all systems</p>
          </div>
          <button
            onClick={handleRefreshAll}
            disabled={refreshing}
            className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200 disabled:opacity-50"
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
            {refreshing ? 'Refreshing...' : 'Refresh All'}
          </button>
        </div>
      </div>

      {/* Connected Integrations Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <div className="flex items-center">
            <Shield className="h-8 w-8 text-blue-600" />
            <div className="ml-4">
              <h3 className="text-lg font-semibold text-gray-900">Active Integrations</h3>
              <p className="text-2xl font-bold text-blue-600">
                {integrations.filter(i => i.status === 'connected').length}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <div className="flex items-center">
            <CheckCircle className="h-8 w-8 text-green-600" />
            <div className="ml-4">
              <h3 className="text-lg font-semibold text-gray-900">Monitored Controls</h3>
              <p className="text-2xl font-bold text-green-600">
                {integrations.reduce((sum, i) => sum + i.controls, 0)}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <div className="flex items-center">
            <AlertCircle className="h-8 w-8 text-red-600" />
            <div className="ml-4">
              <h3 className="text-lg font-semibold text-gray-900">Total Issues</h3>
              <p className="text-2xl font-bold text-red-600">
                {integrations.reduce((sum, i) => sum + i.issues, 0)}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <div className="flex items-center">
            <Zap className="h-8 w-8 text-purple-600" />
            <div className="ml-4">
              <h3 className="text-lg font-semibold text-gray-900">Available</h3>
              <p className="text-2xl font-bold text-purple-600">
                {integrations.filter(i => i.status === 'available').length}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 mb-8">
        <div className="p-6 border-b border-gray-200">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <SearchBar
                placeholder="Search integrations..."
                onSearch={setSearchQuery}
                className="w-full"
              />
            </div>
            <div className="flex gap-2">
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                {categories.map(category => (
                  <option key={category.id} value={category.id}>
                    {category.name} ({category.count})
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Category Tabs */}
        <div className="px-6 py-4 border-b border-gray-200">
          <div className="flex flex-wrap gap-2">
            {categories.map(category => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200 ${
                  selectedCategory === category.id
                    ? 'bg-blue-100 text-blue-700'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                }`}
              >
                {category.name}
                <span className="ml-2 text-xs bg-gray-200 text-gray-600 px-2 py-1 rounded-full">
                  {category.count}
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Integration Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        {filteredIntegrations.map((integration) => {
          const Icon = integration.icon;
          return (
            <div key={integration.id} className="bg-white rounded-xl shadow-sm border border-gray-200 hover:shadow-md transition-all duration-200 group">
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center">
                    <div className="flex-shrink-0 relative">
                      <Icon className="h-8 w-8 text-gray-700" />
                      {integration.popular && (
                        <div className="absolute -top-1 -right-1 w-3 h-3 bg-blue-500 rounded-full"></div>
                      )}
                    </div>
                    <div className="ml-3">
                      <h3 className="text-lg font-semibold text-gray-900">{integration.name}</h3>
                      {integration.popular && (
                        <span className="text-xs text-blue-600 font-medium">Popular</span>
                      )}
                    </div>
                  </div>
                  {getStatusIcon(integration.status)}
                </div>
                
                <p className="text-sm text-gray-600 mb-4">{integration.description}</p>
                
                <div className="flex items-center justify-between mb-4">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(integration.status)}`}>
                    {getStatusText(integration.status)}
                  </span>
                  {integration.lastSync && (
                    <span className="text-xs text-gray-500">
                      Last sync: {integration.lastSync}
                    </span>
                  )}
                </div>

                {integration.status === 'connected' && (
                  <div className="flex justify-between text-sm text-gray-600 mb-4 p-3 bg-gray-50 rounded-lg">
                    <div className="text-center">
                      <div className="font-semibold text-gray-900">{integration.controls}</div>
                      <div className="text-xs">Controls</div>
                    </div>
                    <div className="text-center">
                      <div className={`font-semibold ${integration.issues > 0 ? 'text-red-600' : 'text-green-600'}`}>
                        {integration.issues}
                      </div>
                      <div className="text-xs">Issues</div>
                    </div>
                  </div>
                )}

                <div className="space-y-2">
                  {integration.status === 'connected' ? (
                    <>
                      <div className="flex space-x-2">
                        <button 
                          onClick={() => handleViewDetails(integration)}
                          className="flex-1 bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors duration-200 flex items-center justify-center"
                        >
                          <Eye className="h-4 w-4 mr-1" />
                          View Details
                        </button>
                        <button 
                          onClick={() => handleSync(integration.id)}
                          className="px-3 py-2 border border-gray-300 text-gray-700 rounded-lg text-sm hover:bg-gray-50 transition-colors duration-200"
                        >
                          <RefreshCw className="h-4 w-4" />
                        </button>
                      </div>
                      <div className="flex space-x-2">
                        <button 
                          onClick={() => handleTestConnection(integration)}
                          className="flex-1 border border-gray-300 text-gray-700 px-4 py-2 rounded-lg text-sm hover:bg-gray-50 transition-colors duration-200"
                        >
                          Test Connection
                        </button>
                        <button 
                          onClick={() => handleDisconnect(integration.id)}
                          className="px-3 py-2 border border-red-300 text-red-600 rounded-lg text-sm hover:bg-red-50 transition-colors duration-200"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </>
                  ) : integration.status === 'connecting' ? (
                    <button disabled className="w-full bg-blue-100 text-blue-600 px-4 py-2 rounded-lg text-sm font-medium flex items-center justify-center">
                      <Loader className="h-4 w-4 mr-1 animate-spin" />
                      Connecting...
                    </button>
                  ) : (
                    <button 
                      onClick={() => handleConnect(integration)}
                      className="w-full bg-gray-100 text-gray-700 px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-200 transition-colors duration-200 flex items-center justify-center group-hover:bg-blue-600 group-hover:text-white"
                    >
                      <Plus className="h-4 w-4 mr-1" />
                      Connect
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Connection Modal */}
      <Modal
        isOpen={showConnectionModal}
        onClose={() => setShowConnectionModal(false)}
        title={`Connect ${selectedIntegration?.name}`}
        size="md"
      >
        {selectedIntegration && (
          <div className="space-y-6">
            <p className="text-gray-600">
              Follow the setup instructions to connect your {selectedIntegration.name} account.
            </p>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  API Key / Access Token
                </label>
                <input
                  type="password"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Enter your API key"
                />
              </div>
              
              {selectedIntegration.type === 'aws' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Role ARN
                  </label>
                  <input
                    type="text"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="arn:aws:iam::123456789012:role/SecuroSyncRole"
                  />
                </div>
              )}

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h4 className="font-medium text-blue-900 mb-2">Setup Instructions</h4>
                <ol className="text-sm text-blue-800 space-y-1">
                  <li>1. Create an IAM role with read-only permissions</li>
                  <li>2. Add the SecuroSync trust policy</li>
                  <li>3. Copy the role ARN and paste it above</li>
                  <li>4. Test the connection</li>
                </ol>
              </div>
            </div>

            <div className="flex space-x-3">
              <button
                onClick={() => setShowConnectionModal(false)}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors duration-200"
              >
                Cancel
              </button>
              <button
                onClick={handleConnectionSubmit}
                className="flex-1 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors duration-200"
              >
                Connect
              </button>
            </div>
          </div>
        )}
      </Modal>

      {/* Integration Instructions */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900">Quick Setup Guide</h2>
        </div>
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-medium text-gray-900 mb-2 flex items-center">
                <Cloud className="h-5 w-5 text-blue-600 mr-2" />
                AWS Integration
              </h3>
              <ol className="text-sm text-gray-600 space-y-1 ml-7">
                <li>1. Create an IAM role with read-only permissions</li>
                <li>2. Add the SecuroSync trust policy</li>
                <li>3. Copy the role ARN and paste it above</li>
                <li>4. Test the connection</li>
              </ol>
            </div>
            <div>
              <h3 className="font-medium text-gray-900 mb-2 flex items-center">
                <Github className="h-5 w-5 text-gray-900 mr-2" />
                GitHub Integration
              </h3>
              <ol className="text-sm text-gray-600 space-y-1 ml-7">
                <li>1. Install the SecuroSync GitHub App</li>
                <li>2. Grant access to repositories</li>
                <li>3. Configure audit log access</li>
                <li>4. Enable security scanning</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}