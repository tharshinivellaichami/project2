import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Sparkles, FileText, Shield, AlertTriangle, ArrowLeft, Copy, ThumbsUp, ThumbsDown, RefreshCw } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { useToast } from '../hooks/useToast';

interface Message {
  id: number;
  type: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  actions?: Array<{
    label: string;
    action: () => void;
    icon?: any;
  }>;
}

export default function AIAssistant() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      type: 'assistant',
      content: "Hello! I'm SecuroBot, your AI security compliance assistant. I can help you with SOC 2 compliance questions, explain security controls, generate policy documents, and provide remediation guidance. How can I assist you today?",
      timestamp: new Date(),
      actions: [
        {
          label: 'View SOC 2 Checklist',
          action: () => handleQuickAction('SOC 2 readiness checklist'),
          icon: FileText
        },
        {
          label: 'Explain Critical Findings',
          action: () => handleQuickAction('Explain critical findings'),
          icon: AlertTriangle
        }
      ]
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const location = useLocation();
  const { showToast } = useToast();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Handle control-specific queries from compliance page
  useEffect(() => {
    if (location.state?.control) {
      const control = location.state.control;
      const controlQuery = `How can I fix the issues in ${control.id} - ${control.name}? The current issues are: ${control.issues.join(', ')}`;
      setInputMessage(controlQuery);
    }
  }, [location.state]);

  const quickActions = [
    {
      icon: Shield,
      title: 'How to enable MFA on AWS?',
      description: 'Step-by-step guide for AWS MFA setup'
    },
    {
      icon: FileText,
      title: 'Generate security policy',
      description: 'Create custom security policies for your org'
    },
    {
      icon: AlertTriangle,
      title: 'Explain critical findings',
      description: 'Understand your compliance gaps'
    },
    {
      icon: Sparkles,
      title: 'SOC 2 readiness checklist',
      description: 'Complete checklist for SOC 2 compliance'
    }
  ];

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return;

    const userMessage: Message = {
      id: messages.length + 1,
      type: 'user',
      content: inputMessage,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsTyping(true);

    // Simulate AI response
    setTimeout(() => {
      const responses = getAIResponse(inputMessage);
      
      const assistantMessage: Message = {
        id: messages.length + 2,
        type: 'assistant',
        content: responses.content,
        timestamp: new Date(),
        actions: responses.actions
      };

      setMessages(prev => [...prev, assistantMessage]);
      setIsTyping(false);
    }, 2000);
  };

  const getAIResponse = (query: string) => {
    const lowerQuery = query.toLowerCase();
    
    if (lowerQuery.includes('mfa') || lowerQuery.includes('multi-factor')) {
      return {
        content: "To enable MFA on AWS, follow these steps:\n\n1. **Sign in to AWS Management Console**\n2. **Navigate to IAM service**\n3. **Select 'Users' from the left menu**\n4. **Choose the user you want to enable MFA for**\n5. **Go to the 'Security credentials' tab**\n6. **Click 'Manage' next to 'Assigned MFA device'**\n7. **Choose your MFA device type** (Virtual, Hardware, or SMS)\n8. **Follow the setup wizard**\n\nFor organization-wide enforcement, you should also create an IAM policy that requires MFA for sensitive operations. Would you like me to help you create this policy?",
        actions: [
          {
            label: 'Generate MFA Policy',
            action: () => handleGeneratePolicy('mfa'),
            icon: FileText
          },
          {
            label: 'View AWS Integration',
            action: () => window.open('/integrations?filter=aws', '_blank'),
            icon: Shield
          }
        ]
      };
    }
    
    if (lowerQuery.includes('soc 2') || lowerQuery.includes('checklist')) {
      return {
        content: "Here's a comprehensive SOC 2 readiness checklist:\n\n**Security (CC6)**\n• Implement logical access controls\n• Enable multi-factor authentication\n• Regular access reviews\n• Secure system configurations\n\n**Availability (A1)**\n• Network monitoring\n• Incident response procedures\n• System backups and recovery\n• Performance monitoring\n\n**Processing Integrity (PI1)**\n• Data validation controls\n• Error handling procedures\n• System processing monitoring\n\n**Confidentiality (C1)**\n• Data encryption at rest and in transit\n• Secure data handling procedures\n• Non-disclosure agreements\n\n**Privacy (P1)**\n• Privacy policy and procedures\n• Data retention policies\n• User consent management\n\nWould you like me to dive deeper into any of these areas?",
        actions: [
          {
            label: 'View Compliance Heat Map',
            action: () => window.open('/compliance', '_blank'),
            icon: Shield
          },
          {
            label: 'Generate SOC 2 Report',
            action: () => window.open('/reports', '_blank'),
            icon: FileText
          }
        ]
      };
    }
    
    if (lowerQuery.includes('policy') || lowerQuery.includes('generate')) {
      return {
        content: "I can help you generate a custom security policy. Here's a template for an Information Security Policy:\n\n**Purpose**: This policy establishes the framework for protecting [Company Name]'s information assets.\n\n**Scope**: Applies to all employees, contractors, and third parties with access to company systems.\n\n**Key Requirements**:\n• Password complexity: minimum 12 characters with mixed case, numbers, and symbols\n• MFA required for all system access\n• Regular security awareness training\n• Incident reporting within 24 hours\n• Data classification and handling procedures\n\n**Enforcement**: Violations may result in disciplinary action.\n\n**Review**: This policy will be reviewed annually.\n\nWould you like me to customize this for your specific industry or compliance requirements?",
        actions: [
          {
            label: 'Customize for HIPAA',
            action: () => handleCustomizePolicy('hipaa'),
            icon: FileText
          },
          {
            label: 'Customize for SOC 2',
            action: () => handleCustomizePolicy('soc2'),
            icon: Shield
          }
        ]
      };
    }

    if (lowerQuery.includes('critical') || lowerQuery.includes('findings') || lowerQuery.includes('issues')) {
      return {
        content: "Let me explain the critical findings in your compliance assessment:\n\n**🔴 Critical Issues (3 found):**\n\n1. **CC1.4 - Competence & Training**\n   - No security training program\n   - Outdated procedures\n   - **Impact**: High risk of human error leading to security incidents\n\n2. **CC3.1 - Risk Identification**\n   - No formal risk assessment\n   - Missing risk register\n   - **Impact**: Unable to identify and mitigate potential threats\n\n3. **CC5.3 - Data Protection**\n   - Unencrypted data at rest\n   - Missing data classification\n   - **Impact**: Data breach risk and compliance violations\n\n**Recommended Actions:**\n• Implement security awareness training program\n• Conduct formal risk assessment\n• Enable encryption for all sensitive data\n• Create data classification framework\n\nWould you like detailed remediation steps for any of these issues?",
        actions: [
          {
            label: 'Get Remediation Steps',
            action: () => handleGetRemediation(),
            icon: Sparkles
          },
          {
            label: 'View Heat Map',
            action: () => window.open('/compliance', '_blank'),
            icon: AlertTriangle
          }
        ]
      };
    }
    
    // Default response
    return {
      content: "I understand you're asking about security compliance. I can help you with:\n\n• **SOC 2 compliance guidance** - Controls, requirements, and best practices\n• **Security policy generation** - Custom policies for your organization\n• **Remediation steps** - Fix compliance gaps and security issues\n• **AWS security configuration** - IAM, S3, CloudTrail setup\n• **Risk assessment** - Identify and mitigate security risks\n• **Incident response** - Procedures and documentation\n\nWhat specific area would you like to explore?",
      actions: [
        {
          label: 'SOC 2 Guidance',
          action: () => handleQuickAction('SOC 2 readiness checklist'),
          icon: Shield
        },
        {
          label: 'Generate Policy',
          action: () => handleQuickAction('Generate security policy'),
          icon: FileText
        }
      ]
    };
  };

  const handleQuickAction = (action: string) => {
    setInputMessage(action);
  };

  const handleGeneratePolicy = (type: string) => {
    showToast('success', `Generating ${type.toUpperCase()} policy template...`);
    setTimeout(() => {
      showToast('success', 'Policy template generated! Check your downloads.');
    }, 2000);
  };

  const handleCustomizePolicy = (framework: string) => {
    showToast('info', `Customizing policy for ${framework.toUpperCase()}...`);
    setTimeout(() => {
      showToast('success', `${framework.toUpperCase()} policy template ready!`);
    }, 2000);
  };

  const handleGetRemediation = () => {
    showToast('info', 'Generating detailed remediation steps...');
    setTimeout(() => {
      showToast('success', 'Remediation plan generated! Check the compliance page for updates.');
    }, 2000);
  };

  const handleCopyMessage = (content: string) => {
    navigator.clipboard.writeText(content);
    showToast('success', 'Message copied to clipboard!');
  };

  const handleFeedback = (messageId: number, type: 'positive' | 'negative') => {
    showToast('success', `Thank you for your feedback!`);
  };

  const handleRegenerateResponse = (messageId: number) => {
    showToast('info', 'Regenerating response...');
    // In a real app, this would regenerate the AI response
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="p-6 h-full">
      {/* Back Button */}
      <div className="mb-4">
        <Link 
          to="/dashboard" 
          className="flex items-center text-gray-600 hover:text-gray-900 transition-colors duration-200"
        >
          <ArrowLeft className="h-5 w-5 mr-2" />
          Back to Dashboard
        </Link>
      </div>

      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-900">SecuroBot AI Assistant</h1>
        <p className="text-gray-600 mt-2">Your intelligent security compliance advisor</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 h-full">
        {/* Quick Actions Sidebar */}
        <div className="lg:col-span-1 space-y-4">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
            <h3 className="font-semibold text-gray-900 mb-3">Quick Actions</h3>
            <div className="space-y-3">
              {quickActions.map((action, index) => (
                <button
                  key={index}
                  onClick={() => handleQuickAction(action.title)}
                  className="w-full text-left p-3 rounded-lg border border-gray-200 hover:border-blue-300 hover:bg-blue-50 transition-all duration-200"
                >
                  <div className="flex items-start">
                    <action.icon className="h-5 w-5 text-blue-600 mr-3 mt-0.5 flex-shrink-0" />
                    <div>
                      <h4 className="text-sm font-medium text-gray-900">{action.title}</h4>
                      <p className="text-xs text-gray-500 mt-1">{action.description}</p>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
            <h3 className="font-semibold text-gray-900 mb-3">Recent Topics</h3>
            <div className="space-y-2 text-sm text-gray-600">
              <button 
                onClick={() => handleQuickAction('AWS IAM Configuration')}
                className="block w-full text-left hover:text-blue-600 transition-colors duration-200"
              >
                AWS IAM Configuration
              </button>
              <button 
                onClick={() => handleQuickAction('Data Encryption Standards')}
                className="block w-full text-left hover:text-blue-600 transition-colors duration-200"
              >
                Data Encryption Standards
              </button>
              <button 
                onClick={() => handleQuickAction('Incident Response Plan')}
                className="block w-full text-left hover:text-blue-600 transition-colors duration-200"
              >
                Incident Response Plan
              </button>
              <button 
                onClick={() => handleQuickAction('Access Control Matrix')}
                className="block w-full text-left hover:text-blue-600 transition-colors duration-200"
              >
                Access Control Matrix
              </button>
            </div>
          </div>
        </div>

        {/* Chat Interface */}
        <div className="lg:col-span-3 flex flex-col bg-white rounded-lg shadow-sm border border-gray-200">
          {/* Chat Messages */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`flex max-w-3xl ${message.type === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                  <div className={`flex-shrink-0 ${message.type === 'user' ? 'ml-3' : 'mr-3'}`}>
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      message.type === 'user' ? 'bg-blue-600' : 'bg-green-600'
                    }`}>
                      {message.type === 'user' ? (
                        <User className="h-5 w-5 text-white" />
                      ) : (
                        <Bot className="h-5 w-5 text-white" />
                      )}
                    </div>
                  </div>
                  <div className={`px-4 py-3 rounded-lg ${
                    message.type === 'user' 
                      ? 'bg-blue-600 text-white' 
                      : 'bg-gray-100 text-gray-900'
                  }`}>
                    <div className="whitespace-pre-wrap">{message.content}</div>
                    <div className={`text-xs mt-2 flex items-center justify-between ${
                      message.type === 'user' ? 'text-blue-100' : 'text-gray-500'
                    }`}>
                      <span>{message.timestamp.toLocaleTimeString()}</span>
                      {message.type === 'assistant' && (
                        <div className="flex items-center space-x-2 ml-4">
                          <button
                            onClick={() => handleCopyMessage(message.content)}
                            className="hover:text-gray-700 transition-colors duration-200"
                            title="Copy message"
                          >
                            <Copy className="h-3 w-3" />
                          </button>
                          <button
                            onClick={() => handleFeedback(message.id, 'positive')}
                            className="hover:text-green-600 transition-colors duration-200"
                            title="Good response"
                          >
                            <ThumbsUp className="h-3 w-3" />
                          </button>
                          <button
                            onClick={() => handleFeedback(message.id, 'negative')}
                            className="hover:text-red-600 transition-colors duration-200"
                            title="Poor response"
                          >
                            <ThumbsDown className="h-3 w-3" />
                          </button>
                          <button
                            onClick={() => handleRegenerateResponse(message.id)}
                            className="hover:text-blue-600 transition-colors duration-200"
                            title="Regenerate response"
                          >
                            <RefreshCw className="h-3 w-3" />
                          </button>
                        </div>
                      )}
                    </div>
                    
                    {/* Action Buttons */}
                    {message.actions && (
                      <div className="mt-3 flex flex-wrap gap-2">
                        {message.actions.map((action, index) => (
                          <button
                            key={index}
                            onClick={action.action}
                            className="flex items-center px-3 py-1 bg-white bg-opacity-20 rounded-lg text-xs font-medium hover:bg-opacity-30 transition-all duration-200"
                          >
                            {action.icon && <action.icon className="h-3 w-3 mr-1" />}
                            {action.label}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
            
            {isTyping && (
              <div className="flex justify-start">
                <div className="flex">
                  <div className="flex-shrink-0 mr-3">
                    <div className="w-8 h-8 rounded-full bg-green-600 flex items-center justify-center">
                      <Bot className="h-5 w-5 text-white" />
                    </div>
                  </div>
                  <div className="px-4 py-3 rounded-lg bg-gray-100">
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                    </div>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Chat Input */}
          <div className="border-t border-gray-200 p-4">
            <div className="flex space-x-3">
              <div className="flex-1">
                <textarea
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Ask me about security compliance, SOC 2 controls, or get help with implementation..."
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                  rows={3}
                />
              </div>
              <button
                onClick={handleSendMessage}
                disabled={!inputMessage.trim() || isTyping}
                className="flex-shrink-0 bg-blue-600 text-white p-3 rounded-lg hover:bg-blue-700 transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Send className="h-5 w-5" />
              </button>
            </div>
            <div className="mt-2 text-xs text-gray-500">
              Press Enter to send, Shift+Enter for new line
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}