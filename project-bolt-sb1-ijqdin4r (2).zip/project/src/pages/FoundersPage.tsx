import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Shield, 
  Brain, 
  Target, 
  Code, 
  Lock, 
  Zap,
  Users,
  ArrowLeft,
  Github,
  Linkedin,
  Mail
} from 'lucide-react';

export default function FoundersPage() {
  const founders = [
    {
      name: 'Tonil Kumar V',
      role: 'Founder & CEO',
      image: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
      description: 'Tonil is a cybersecurity expert and ethical hacker with a proven background in bug bounty hunting, backend development, and network proxy analysis. Before founding SecuroSync, he spent years exploring vulnerabilities in real-world systems — giving him a practical edge in building defensive, AI-backed infrastructure. As CEO, Tonil leads the product and security architecture while ensuring every feature aligns with real user pain points.',
      skills: ['Web application pentesting', 'Secure backend design', 'Infrastructure planning', 'AI integration for vulnerability detection'],
      icon: Lock,
      color: 'blue'
    },
    {
      name: 'Gowtham S',
      role: 'Co-founder & CTO',
      image: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
      description: 'Gowtham is a full-stack developer and AI engineer specializing in LLM training, dataset engineering, and system modulation. He leads SecuroSync\'s core architecture — building and scaling the AI engine that powers our compliance intelligence and automation. With a strong background in AI ops and platform development, Gowtham ensures the product evolves with performance, scalability, and precision.',
      skills: ['LLMs', 'AI pipelines', 'Cloud infrastructure', 'Full-stack architecture', 'Product scalability'],
      icon: Brain,
      color: 'purple'
    },
    {
      name: 'Jaya Devi R',
      role: 'Co-founder & Chief Strategy Officer (CSO)',
      image: 'https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
      description: 'Jaya brings the business and strategic firepower to SecuroSync. She manages the company\'s go-to-market roadmap, partnerships with audit and CPA firms, branding, and expansion strategy. With a clear focus on trust, growth, and market differentiation, she bridges the technical and business sides to scale operations effectively.',
      skills: ['Compliance strategy', 'Audit workflow optimization', 'Growth partnerships', 'Investor alignment'],
      icon: Target,
      color: 'green'
    }
  ];

  const getColorClasses = (color: string) => {
    switch (color) {
      case 'blue':
        return {
          bg: 'bg-blue-100',
          text: 'text-blue-600',
          border: 'border-blue-200',
          gradient: 'from-blue-500 to-blue-600'
        };
      case 'purple':
        return {
          bg: 'bg-purple-100',
          text: 'text-purple-600',
          border: 'border-purple-200',
          gradient: 'from-purple-500 to-purple-600'
        };
      case 'green':
        return {
          bg: 'bg-green-100',
          text: 'text-green-600',
          border: 'border-green-200',
          gradient: 'from-green-500 to-green-600'
        };
      default:
        return {
          bg: 'bg-gray-100',
          text: 'text-gray-600',
          border: 'border-gray-200',
          gradient: 'from-gray-500 to-gray-600'
        };
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Navigation */}
      <nav className="relative px-4 md:px-6 py-3 md:py-4 bg-white shadow-sm">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link 
              to="/" 
              className="flex items-center text-gray-600 hover:text-gray-900 transition-colors duration-200"
            >
              <ArrowLeft className="h-4 w-4 md:h-5 md:w-5 mr-2" />
              <span className="text-sm md:text-base">Back to Home</span>
            </Link>
          </div>
          <div className="flex items-center space-x-1 md:space-x-2">
            <Shield className="h-6 w-6 md:h-8 md:w-8 text-blue-600" />
            <span className="text-xl md:text-2xl font-bold text-gray-900">SecuroSync</span>
          </div>
          <div className="flex items-center space-x-2 md:space-x-4">
            <Link 
              to="/login" 
              className="text-gray-600 hover:text-gray-900 transition-colors duration-200 text-sm md:text-base"
            >
              Login
            </Link>
            <Link 
              to="/wishlist" 
              className="bg-blue-600 hover:bg-blue-700 text-white px-3 md:px-4 py-2 rounded-lg transition-colors duration-200 text-sm md:text-base"
            >
              Request Access
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="px-4 md:px-6 py-8 md:py-16">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 mb-4 md:mb-6">
            Meet the 
            <span className="text-blue-600"> Founders</span>
          </h1>
          <p className="text-lg md:text-xl text-gray-600 mb-6 md:mb-8 max-w-3xl mx-auto leading-relaxed">
            At the heart of SecuroSync is a founding team driven by deep technical expertise, 
            real-world security experience, and bold strategic vision. Together, they're redefining 
            how companies approach compliance, infrastructure security, and AI integration.
          </p>
        </div>
      </div>

      {/* Founders Section */}
      <div className="px-4 md:px-6 pb-12 md:pb-16">
        <div className="max-w-7xl mx-auto">
          <div className="space-y-12 md:space-y-16">
            {founders.map((founder, index) => {
              const colors = getColorClasses(founder.color);
              const Icon = founder.icon;
              const isEven = index % 2 === 0;
              
              return (
                <div 
                  key={index}
                  className={`flex flex-col ${isEven ? 'lg:flex-row' : 'lg:flex-row-reverse'} items-center gap-8 md:gap-12`}
                >
                  {/* Image Section */}
                  <div className="lg:w-1/3 flex justify-center">
                    <div className="relative">
                      <div className={`absolute inset-0 bg-gradient-to-br ${colors.gradient} rounded-2xl transform rotate-3`}></div>
                      <div className="relative bg-white p-2 rounded-2xl shadow-xl">
                        <img
                          src={founder.image}
                          alt={founder.name}
                          className="w-64 h-64 md:w-80 md:h-80 object-cover rounded-xl"
                        />
                        <div className={`absolute -top-2 -right-2 md:-top-4 md:-right-4 w-12 h-12 md:w-16 md:h-16 ${colors.bg} rounded-full flex items-center justify-center shadow-lg`}>
                          <Icon className={`h-6 w-6 md:h-8 md:w-8 ${colors.text}`} />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Content Section */}
                  <div className="lg:w-2/3 space-y-4 md:space-y-6 text-center lg:text-left">
                    <div>
                      <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">{founder.name}</h2>
                      <p className={`text-lg md:text-xl font-semibold ${colors.text} mb-3 md:mb-4`}>{founder.role}</p>
                    </div>

                    <p className="text-gray-600 text-base md:text-lg leading-relaxed">
                      {founder.description}
                    </p>

                    {/* Skills */}
                    <div>
                      <h3 className="text-base md:text-lg font-semibold text-gray-900 mb-3">🛠 Core Skills & Expertise</h3>
                      <div className="flex flex-wrap gap-2 justify-center lg:justify-start">
                        {founder.skills.map((skill, skillIndex) => (
                          <span
                            key={skillIndex}
                            className={`px-2 md:px-3 py-1 ${colors.bg} ${colors.text} rounded-full text-xs md:text-sm font-medium`}
                          >
                            {skill}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Social Links */}
                    <div className="flex space-x-3 md:space-x-4 pt-4 justify-center lg:justify-start">
                      <button className="p-2 md:p-3 bg-gray-100 hover:bg-gray-200 rounded-full transition-colors duration-200">
                        <Linkedin className="h-4 w-4 md:h-5 md:w-5 text-gray-600" />
                      </button>
                      <button className="p-2 md:p-3 bg-gray-100 hover:bg-gray-200 rounded-full transition-colors duration-200">
                        <Github className="h-4 w-4 md:h-5 md:w-5 text-gray-600" />
                      </button>
                      <button className="p-2 md:p-3 bg-gray-100 hover:bg-gray-200 rounded-full transition-colors duration-200">
                        <Mail className="h-4 w-4 md:h-5 md:w-5 text-gray-600" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Why This Team Works Section */}
      <div className="px-4 md:px-6 py-12 md:py-16 bg-white">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8 md:mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-3 md:mb-4">💡 Why This Team Works</h2>
            <p className="text-lg md:text-xl text-gray-600">
              The perfect blend of technical depth, security expertise, and strategic vision
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6 md:gap-8">
            <div className="text-center p-4 md:p-6 rounded-xl bg-gradient-to-br from-blue-50 to-blue-100 border border-blue-200">
              <div className="w-12 h-12 md:w-16 md:h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-3 md:mb-4">
                <Code className="h-6 w-6 md:h-8 md:w-8 text-white" />
              </div>
              <h3 className="text-base md:text-lg font-semibold text-gray-900 mb-2">Deeply Technical, Yet User-Obsessed</h3>
              <p className="text-gray-600 text-sm md:text-base">
                We build with both technical excellence and user experience at the forefront
              </p>
            </div>

            <div className="text-center p-4 md:p-6 rounded-xl bg-gradient-to-br from-purple-50 to-purple-100 border border-purple-200">
              <div className="w-12 h-12 md:w-16 md:h-16 bg-purple-600 rounded-full flex items-center justify-center mx-auto mb-3 md:mb-4">
                <Shield className="h-6 w-6 md:h-8 md:w-8 text-white" />
              </div>
              <h3 className="text-base md:text-lg font-semibold text-gray-900 mb-2">We've Lived the Compliance Pain</h3>
              <p className="text-gray-600 text-sm md:text-base">
                Real-world experience with security challenges gives us unique insight into solutions
              </p>
            </div>

            <div className="text-center p-4 md:p-6 rounded-xl bg-gradient-to-br from-green-50 to-green-100 border border-green-200">
              <div className="w-12 h-12 md:w-16 md:h-16 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-3 md:mb-4">
                <Zap className="h-6 w-6 md:h-8 md:w-8 text-white" />
              </div>
              <h3 className="text-base md:text-lg font-semibold text-gray-900 mb-2">Move Fast, Build Smart</h3>
              <p className="text-gray-600 text-sm md:text-base">
                We keep our users ahead of threats — not chasing them
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="px-4 md:px-6 py-12 md:py-16 bg-gradient-to-br from-blue-900 via-blue-800 to-teal-900">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-3 md:mb-4">
            Ready to work with our team?
          </h2>
          <p className="text-lg md:text-xl text-blue-100 mb-6 md:mb-8">
            Join our exclusive early access program and work directly with the founding team.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 md:gap-4 justify-center">
            <Link 
              to="/wishlist" 
              className="bg-white text-blue-900 px-6 md:px-8 py-3 md:py-4 rounded-lg text-base md:text-lg font-semibold transition-all duration-200 transform hover:scale-105"
            >
              Request Early Access
            </Link>
            <Link 
              to="/login" 
              className="border-2 border-white text-white hover:bg-white hover:text-blue-900 px-6 md:px-8 py-3 md:py-4 rounded-lg text-base md:text-lg font-semibold transition-all duration-200"
            >
              Already Have Access?
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}