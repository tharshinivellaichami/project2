import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Shield, 
  CheckCircle, 
  Zap, 
  Users, 
  TrendingUp, 
  Bot, 
  Menu, 
  X, 
  Star, 
  ArrowRight, 
  Play,
  Lock,
  FileText,
  Activity,
  Vault,
  Settings,
  Bell,
  MessageSquare,
  Brain,
  ClipboardCheck,
  Clock
} from 'lucide-react';

export default function LandingPage() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const features = [
    {
      icon: Shield,
      title: 'Real-time Compliance Monitoring',
      description: 'Continuously monitor your infrastructure against SOC 2, ISO 27001, and HIPAA requirements with automated scanning and real-time alerts.',
      category: 'core'
    },
    {
      icon: Zap,
      title: 'AI-Powered Remediation',
      description: 'Get intelligent recommendations and automated fixes for compliance gaps with step-by-step guidance and implementation support.',
      category: 'core'
    },
    {
      icon: TrendingUp,
      title: 'Heat Map Visualizations',
      description: 'Visual compliance dashboards that make complex security data easy to understand with interactive charts and progress tracking.',
      category: 'core'
    },
    {
      icon: Users,
      title: 'Infrastructure Syncing',
      description: 'Seamlessly integrate with AWS, GitHub, Azure, and your existing CI/CD pipelines for comprehensive coverage.',
      category: 'core'
    },
    {
      icon: Bot,
      title: 'SecuroBot Assistant',
      description: 'Your AI security advisor available 24/7 to answer questions, guide implementation, and provide expert recommendations.',
      category: 'core'
    },
    {
      icon: CheckCircle,
      title: 'Audit-Ready Reports',
      description: 'Generate comprehensive compliance reports and evidence collection for auditors with one-click export functionality.',
      category: 'core'
    },
    {
      icon: Lock,
      title: 'Access Management Dashboard',
      description: 'Role-based access control (RBAC) to manage who has access to compliance roles, audit logs, and sensitive data.',
      category: 'advanced'
    },
    {
      icon: Activity,
      title: 'User Activity Logs',
      description: 'Complete traceability showing who did what and when. Essential for SOC 2, HIPAA, and audit requirements.',
      category: 'advanced'
    },
    {
      icon: Vault,
      title: 'Evidence Locker',
      description: 'Secure vault to store compliance artifacts like risk assessments, policy files, and vendor risk reviews.',
      category: 'advanced'
    },
    {
      icon: Settings,
      title: 'Integration Settings UI',
      description: 'Visual interface to test and manage integrations with AWS, GitHub, Slack, Jira, and other critical tools.',
      category: 'advanced'
    },
    {
      icon: Bell,
      title: 'Notification & Alert System',
      description: 'Email and Slack alerts for remediation status, new risks detected, audit deadlines, and compliance updates.',
      category: 'advanced'
    },
    {
      icon: MessageSquare,
      title: 'Team Collaboration Tools',
      description: 'Notes, comments, and task assignments for compliance tasks. Encourages shared accountability across teams.',
      category: 'coming-soon',
      comingSoon: true
    },
    {
      icon: Brain,
      title: 'Automated Policy Generator',
      description: 'AI-powered generation of SOC 2, HIPAA, and ISO 27001 policy documents tailored to your organization.',
      category: 'coming-soon',
      comingSoon: true
    },
    {
      icon: ClipboardCheck,
      title: 'Security Questionnaire Automation',
      description: 'Automatically answer security forms like CAIQ and SIG using AI, saving hours of manual work.',
      category: 'coming-soon',
      comingSoon: true
    },
    {
      icon: FileText,
      title: 'Custom Framework Support',
      description: 'Create or import your own compliance frameworks beyond standard SOC 2, ISO 27001, and HIPAA.',
      category: 'coming-soon',
      comingSoon: true
    }
  ];

  const testimonials = [
    {
      name: 'Sarah Chen',
      role: 'CTO at TechFlow',
      company: 'TechFlow Inc.',
      content: 'SecuroSync reduced our SOC 2 preparation time from 6 months to 6 weeks. The AI recommendations were spot-on.',
      rating: 5
    },
    {
      name: 'Michael Rodriguez',
      role: 'Security Engineer',
      company: 'DataVault',
      content: 'The real-time monitoring caught issues we never would have found manually. Game-changer for our security posture.',
      rating: 5
    },
    {
      name: 'Emily Johnson',
      role: 'Compliance Manager',
      company: 'HealthTech Solutions',
      content: 'Finally, a compliance tool that actually understands our infrastructure. The heat maps make everything crystal clear.',
      rating: 5
    }
  ];

  const stats = [
    { number: '1000+', label: 'Early Access Users' },
    { number: '99.9%', label: 'Uptime Guarantee' },
    { number: '75%', label: 'Faster Compliance' },
    { number: '24/7', label: 'AI Support' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-teal-900">
      {/* Navigation */}
      <nav className="relative px-4 md:px-6 py-3 md:py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-1 md:space-x-2">
            <Shield className="h-6 w-6 md:h-8 md:w-8 text-blue-400" />
            <span className="text-xl md:text-2xl font-bold text-white">SecuroSync</span>
          </div>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-6 lg:space-x-8">
            <Link 
              to="/founders" 
              className="text-white hover:text-blue-300 transition-colors duration-200 text-sm lg:text-base"
            >
              About Team
            </Link>
            <a 
              href="#features-section"
              className="text-white hover:text-blue-300 transition-colors duration-200 text-sm lg:text-base cursor-pointer"
            >
              Features
            </a>
            <Link 
              to="/login" 
              className="text-white hover:text-blue-300 transition-colors duration-200 text-sm lg:text-base"
            >
              Login
            </Link>
            <Link 
              to="/wishlist" 
              className="bg-blue-600 hover:bg-blue-700 text-white px-3 lg:px-4 py-2 rounded-lg transition-colors duration-200 text-sm lg:text-base"
            >
              Request Access
            </Link>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="text-white hover:text-blue-300 transition-colors duration-200"
            >
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="md:hidden absolute top-full left-0 right-0 bg-blue-900 border-t border-blue-700 px-4 md:px-6 py-4 space-y-4 z-50">
            <Link 
              to="/founders" 
              className="block text-white hover:text-blue-300 transition-colors duration-200"
              onClick={() => setMobileMenuOpen(false)}
            >
              About Team
            </Link>
            <a 
              href="#features-section"
              className="block text-white hover:text-blue-300 transition-colors duration-200 text-left cursor-pointer"
              onClick={() => setMobileMenuOpen(false)}
            >
              Features
            </a>
            <Link 
              to="/login" 
              className="block text-white hover:text-blue-300 transition-colors duration-200"
              onClick={() => setMobileMenuOpen(false)}
            >
              Login
            </Link>
            <Link 
              to="/wishlist" 
              className="block bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors duration-200 text-center"
              onClick={() => setMobileMenuOpen(false)}
            >
              Request Access
            </Link>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <div className="px-4 md:px-6 py-8 md:py-16">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-8 md:mb-12">
            <div className="inline-flex items-center px-3 md:px-4 py-2 bg-blue-800 bg-opacity-50 rounded-full text-blue-200 text-xs md:text-sm font-medium mb-4 md:mb-6">
              <Star className="h-3 w-3 md:h-4 md:w-4 mr-2" />
              Limited Early Access - MVP Phase
            </div>
            <h1 className="text-4xl md:text-5xl lg:text-7xl font-bold text-white mb-4 md:mb-6 leading-tight">
              Your AI-Powered 
              <span className="text-blue-400"> CISO</span>
            </h1>
            <p className="text-lg md:text-xl lg:text-2xl text-blue-100 mb-6 md:mb-8 max-w-4xl mx-auto leading-relaxed px-4">
              Achieve infrastructure security compliance with real-time monitoring, 
              AI-guided remediation, and automated audit reporting. Built for startups and mid-size tech companies.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 md:gap-4 justify-center mb-8 md:mb-12 px-4">
              <Link 
                to="/wishlist" 
                className="bg-blue-600 hover:bg-blue-700 text-white px-6 md:px-8 py-3 md:py-4 rounded-lg text-base md:text-lg font-semibold transition-all duration-200 transform hover:scale-105 flex items-center justify-center"
              >
                Request Early Access
                <ArrowRight className="ml-2 h-4 w-4 md:h-5 md:w-5" />
              </Link>
              <button className="border-2 border-white text-white hover:bg-white hover:text-blue-900 px-6 md:px-8 py-3 md:py-4 rounded-lg text-base md:text-lg font-semibold transition-all duration-200 flex items-center justify-center">
                <Play className="mr-2 h-4 w-4 md:h-5 md:w-5" />
                Watch Demo
              </button>
            </div>
            <div className="bg-blue-800 bg-opacity-30 rounded-lg p-3 md:p-4 max-w-2xl mx-auto">
              <p className="text-blue-100 text-xs md:text-sm">
                🚀 <strong>MVP Phase:</strong> We're currently selecting early adopters for our limited access program. 
                Submit your request and we'll send you login credentials within 24-48 hours.
              </p>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-8 mb-12 md:mb-16">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-2xl md:text-3xl lg:text-4xl font-bold text-white mb-1 md:mb-2">{stat.number}</div>
                <div className="text-blue-200 text-sm md:text-base">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div id="features-section" className="px-4 md:px-6 py-12 md:py-20 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12 md:mb-16">
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 mb-4 md:mb-6">
              Complete AI-Powered Compliance Platform
            </h2>
            <p className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto">
              From real-time monitoring to AI-powered automation, SecuroSync provides everything you need for enterprise-grade compliance
            </p>
          </div>
          
          {/* Core Features */}
          <div className="mb-16">
            <div className="text-center mb-8">
              <h3 className="text-2xl md:text-3xl font-bold text-gray-900 mb-3">Core Platform Features</h3>
              <p className="text-gray-600">Essential tools for comprehensive compliance management</p>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
              {features.filter(f => f.category === 'core').map((feature, index) => (
                <div 
                  key={index}
                  className="group p-6 md:p-8 rounded-2xl border border-gray-200 hover:border-blue-300 hover:shadow-xl transition-all duration-300 bg-white"
                >
                  <div className="w-12 h-12 md:w-16 md:h-16 bg-blue-100 rounded-2xl flex items-center justify-center mb-4 md:mb-6 group-hover:bg-blue-600 transition-colors duration-300">
                    <feature.icon className="h-6 w-6 md:h-8 md:w-8 text-blue-600 group-hover:text-white transition-colors duration-300" />
                  </div>
                  <h3 className="text-lg md:text-xl font-semibold text-gray-900 mb-3 md:mb-4">
                    {feature.title}
                  </h3>
                  <p className="text-gray-600 leading-relaxed text-sm md:text-base">
                    {feature.description}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Advanced Features */}
          <div className="mb-16">
            <div className="text-center mb-8">
              <h3 className="text-2xl md:text-3xl font-bold text-gray-900 mb-3">Advanced Compliance Tools</h3>
              <p className="text-gray-600">Enterprise-grade features for comprehensive security management</p>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
              {features.filter(f => f.category === 'advanced').map((feature, index) => (
                <div 
                  key={index}
                  className="group p-6 md:p-8 rounded-2xl border border-gray-200 hover:border-purple-300 hover:shadow-xl transition-all duration-300 bg-white"
                >
                  <div className="w-12 h-12 md:w-16 md:h-16 bg-purple-100 rounded-2xl flex items-center justify-center mb-4 md:mb-6 group-hover:bg-purple-600 transition-colors duration-300">
                    <feature.icon className="h-6 w-6 md:h-8 md:w-8 text-purple-600 group-hover:text-white transition-colors duration-300" />
                  </div>
                  <h3 className="text-lg md:text-xl font-semibold text-gray-900 mb-3 md:mb-4">
                    {feature.title}
                  </h3>
                  <p className="text-gray-600 leading-relaxed text-sm md:text-base">
                    {feature.description}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* AI-Powered Features */}
          {/* Coming Soon Features */}
          <div>
            <div className="text-center mb-8">
              <h3 className="text-2xl md:text-3xl font-bold text-gray-900 mb-3">Coming Soon</h3>
              <p className="text-gray-600">Future features that will expand SecuroSync's capabilities even further</p>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
              {features.filter(f => f.category === 'coming-soon').map((feature, index) => (
                <div 
                  key={index}
                  className="group p-6 md:p-8 rounded-2xl border border-gray-200 hover:border-orange-300 hover:shadow-xl transition-all duration-300 bg-white relative overflow-hidden"
                >
                  <div className="absolute top-4 right-4">
                    <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-orange-100 text-orange-800">
                      <Clock className="h-3 w-3 mr-1" />
                      Coming Soon
                    </span>
                  </div>
                  <div className="w-12 h-12 md:w-16 md:h-16 bg-orange-100 rounded-2xl flex items-center justify-center mb-4 md:mb-6 group-hover:bg-orange-600 transition-colors duration-300">
                    <feature.icon className="h-6 w-6 md:h-8 md:w-8 text-orange-600 group-hover:text-white transition-colors duration-300" />
                  </div>
                  <h3 className="text-lg md:text-xl font-semibold text-gray-900 mb-3 md:mb-4">
                    {feature.title}
                  </h3>
                  <p className="text-gray-600 leading-relaxed text-sm md:text-base">
                    {feature.description}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Feature Categories Summary */}
          <div className="mt-16 bg-gradient-to-br from-blue-50 to-purple-50 rounded-2xl p-8 md:p-12">
            <div className="text-center mb-8">
              <h3 className="text-2xl md:text-3xl font-bold text-gray-900 mb-4">Why SecuroSync Stands Out</h3>
              <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                Unlike traditional compliance tools, SecuroSync combines real-time monitoring, AI automation, and comprehensive team collaboration in one platform
              </p>
            </div>
            
            <div className="grid md:grid-cols-3 gap-6 md:gap-8">
              <div 
                className="text-center p-6 bg-white rounded-xl shadow-sm border border-gray-200"
              >
                <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <Shield className="h-6 w-6 text-blue-600" />
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Real-Time Monitoring</h4>
                <p className="text-sm text-gray-600">
                  Continuous compliance monitoring across all your infrastructure and applications
                </p>
              </div>
              
              <div 
                className="text-center p-6 bg-white rounded-xl shadow-sm border border-gray-200"
              >
                <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <Bot className="h-6 w-6 text-purple-600" />
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">AI-First Approach</h4>
                <p className="text-sm text-gray-600">
                  Intelligent automation that learns from your environment and provides smart recommendations
                </p>
              </div>
              
              <div 
                className="text-center p-6 bg-white rounded-xl shadow-sm border border-gray-200"
              >
                <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <Users className="h-6 w-6 text-green-600" />
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Team Collaboration</h4>
                <p className="text-sm text-gray-600">
                  Built for teams with role-based access, activity tracking, and collaborative workflows
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Testimonials Section */}
      <div className="px-4 md:px-6 py-12 md:py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12 md:mb-16">
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 mb-4 md:mb-6">
              Loved by security teams worldwide
            </h2>
            <p className="text-lg md:text-xl text-gray-600">
              See what our customers are saying about SecuroSync
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-white p-6 md:p-8 rounded-2xl shadow-sm border border-gray-200">
                <div className="flex items-center mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 md:h-5 md:w-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-600 mb-4 md:mb-6 leading-relaxed text-sm md:text-base">"{testimonial.content}"</p>
                <div>
                  <div className="font-semibold text-gray-900 text-sm md:text-base">{testimonial.name}</div>
                  <div className="text-xs md:text-sm text-gray-500">{testimonial.role}</div>
                  <div className="text-xs md:text-sm text-blue-600">{testimonial.company}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="px-4 md:px-6 py-12 md:py-20 bg-blue-900">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4 md:mb-6">
            Ready to secure your infrastructure?
          </h2>
          <p className="text-lg md:text-xl text-blue-100 mb-6 md:mb-8">
            Join our exclusive early access program and be among the first to experience AI-powered compliance.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 md:gap-4 justify-center">
            <Link 
              to="/wishlist" 
              className="bg-blue-600 hover:bg-blue-700 text-white px-6 md:px-8 py-3 md:py-4 rounded-lg text-base md:text-lg font-semibold transition-all duration-200 transform hover:scale-105"
            >
              Request Early Access
            </Link>
            <Link 
              to="/login" 
              className="border-2 border-white text-white hover:bg-white hover:text-blue-900 px-6 md:px-8 py-3 md:py-4 rounded-lg text-base md:text-lg font-semibold transition-all duration-200"
            >
              Already Have Access?
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}