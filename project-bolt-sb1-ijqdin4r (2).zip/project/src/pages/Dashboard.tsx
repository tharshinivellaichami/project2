import React, { useState, useEffect } from 'react';
import { 
  Shield, 
  TrendingUp, 
  AlertTriangle, 
  CheckCircle, 
  Users, 
  Server,
  Github,
  Cloud,
  Activity,
  RefreshCw,
  ExternalLink,
  Calendar,
  Clock,
  Settings,
  FileText,
  Bot,
  Eye,
  ArrowRight
} from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import LoadingSpinner from '../components/LoadingSpinner';
import { useToast } from '../hooks/useToast';
import { dashboardAPI } from '../services/api';

interface DashboardData {
  complianceScore: number;
  stats: {
    totalControls: number;
    passedControls: number;
    warningIssues: number;
    criticalIssues: number;
  };
  recentActivity: Array<{
    id: string;
    type: string;
    message: string;
    time: string;
    severity: string;
    user: string;
  }>;
  upcomingTasks: Array<{
    task: string;
    due: string;
    priority: string;
  }>;
  controlsByCategory: Array<{
    name: string;
    status: string;
    score: number;
    issues: number;
    trend: string;
  }>;
}

export default function Dashboard() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [lastUpdated, setLastUpdated] = useState(new Date());
  const [dashboardData, setDashboardData] = useState<DashboardData | null>(null);
  const navigate = useNavigate();
  const { showToast } = useToast();

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      setLoading(true);
      const response = await dashboardAPI.getOverview();
      if (response.success) {
        setDashboardData(response.data);
        setLastUpdated(new Date());
      } else {
        showToast('error', 'Failed to load dashboard data');
      }
    } catch (error) {
      console.error('Dashboard load error:', error);
      showToast('error', 'Failed to load dashboard data');
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    try {
      await loadDashboardData();
      showToast('success', 'Dashboard data refreshed successfully');
    } catch (error) {
      showToast('error', 'Failed to refresh dashboard data');
    } finally {
      setRefreshing(false);
    }
  };

  const handleViewDetails = (type: string) => {
    switch (type) {
      case 'critical':
        navigate('/compliance?filter=critical');
        break;
      case 'warnings':
        navigate('/compliance?filter=warning');
        break;
      case 'controls':
        navigate('/compliance');
        break;
      default:
        navigate('/compliance');
    }
  };

  const handleQuickAction = async (action: string) => {
    switch (action) {
      case 'run-assessment':
        try {
          showToast('info', 'Starting compliance assessment...');
          const response = await dashboardAPI.runAssessment();
          if (response.success) {
            showToast('success', 'Assessment started successfully!');
            // Refresh dashboard data after a delay
            setTimeout(() => {
              loadDashboardData();
            }, 3000);
          }
        } catch (error) {
          showToast('error', 'Failed to start assessment');
        }
        break;
      case 'generate-report':
        navigate('/reports');
        break;
      case 'ask-ai':
        navigate('/assistant');
        break;
      case 'view-integrations':
        navigate('/integrations');
        break;
      default:
        showToast('info', `${action} feature coming soon!`);
    }
  };

  const quickActions = [
    {
      title: 'Run Assessment',
      description: 'Start a new compliance assessment',
      icon: Activity,
      color: 'blue',
      action: () => handleQuickAction('run-assessment')
    },
    {
      title: 'Generate Report',
      description: 'Create compliance report',
      icon: FileText,
      color: 'green',
      action: () => handleQuickAction('generate-report')
    },
    {
      title: 'Ask SecuroBot',
      description: 'Get AI assistance',
      icon: Bot,
      color: 'purple',
      action: () => handleQuickAction('ask-ai')
    },
    {
      title: 'Manage Integrations',
      description: 'Configure connections',
      icon: Settings,
      color: 'orange',
      action: () => handleQuickAction('view-integrations')
    }
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <LoadingSpinner size="lg" />
          <p className="mt-4 text-gray-600">Loading your security dashboard...</p>
        </div>
      </div>
    );
  }

  if (!dashboardData) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <AlertTriangle className="h-12 w-12 text-red-500 mx-auto mb-4" />
          <p className="text-gray-600">Failed to load dashboard data</p>
          <button 
            onClick={loadDashboardData}
            className="mt-4 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors duration-200"
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'passed': return 'text-green-600 bg-green-100';
      case 'warning': return 'text-yellow-600 bg-yellow-100';
      case 'critical': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getActivityIcon = (severity: string) => {
    switch (severity) {
      case 'success': return 'text-green-500 bg-green-100';
      case 'warning': return 'text-yellow-500 bg-yellow-100';
      case 'critical': return 'text-red-500 bg-red-100';
      case 'info': return 'text-blue-500 bg-blue-100';
      default: return 'text-gray-500 bg-gray-100';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'text-red-600 bg-red-100';
      case 'medium': return 'text-yellow-600 bg-yellow-100';
      case 'low': return 'text-green-600 bg-green-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getActionColor = (color: string) => {
    switch (color) {
      case 'blue': return 'bg-blue-100 text-blue-600 hover:bg-blue-200';
      case 'green': return 'bg-green-100 text-green-600 hover:bg-green-200';
      case 'purple': return 'bg-purple-100 text-purple-600 hover:bg-purple-200';
      case 'orange': return 'bg-orange-100 text-orange-600 hover:bg-orange-200';
      default: return 'bg-gray-100 text-gray-600 hover:bg-gray-200';
    }
  };

  return (
    <div className="p-6">
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Security Dashboard</h1>
            <p className="text-gray-600 mt-2">Monitor your security posture and compliance status</p>
          </div>
          <div className="flex items-center space-x-4">
            <div className="text-sm text-gray-500 flex items-center">
              <Clock className="h-4 w-4 mr-1" />
              Last updated: {lastUpdated.toLocaleTimeString()}
            </div>
            <button
              onClick={handleRefresh}
              disabled={refreshing}
              className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200 disabled:opacity-50"
            >
              <RefreshCw className={`h-4 w-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
              {refreshing ? 'Refreshing...' : 'Refresh'}
            </button>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {quickActions.map((action, index) => (
          <button
            key={index}
            onClick={action.action}
            className={`p-4 rounded-xl transition-all duration-200 transform hover:scale-105 ${getActionColor(action.color)}`}
          >
            <action.icon className="h-6 w-6 mb-2" />
            <h3 className="font-semibold text-sm">{action.title}</h3>
            <p className="text-xs opacity-75">{action.description}</p>
          </button>
        ))}
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 hover:shadow-md transition-shadow duration-200">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-blue-100">
              <TrendingUp className="h-6 w-6 text-blue-600" />
            </div>
            <div className="ml-4">
              <h3 className="text-sm font-medium text-gray-500">Compliance Score</h3>
              <div className="flex items-center">
                <p className="text-2xl font-bold text-gray-900">{dashboardData.complianceScore}%</p>
                <span className="ml-2 text-sm text-green-600">+5%</span>
              </div>
            </div>
          </div>
          <div className="mt-4">
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className="bg-blue-600 h-2 rounded-full transition-all duration-500"
                style={{ width: `${dashboardData.complianceScore}%` }}
              />
            </div>
          </div>
          <div className="mt-4">
            <button 
              onClick={() => navigate('/compliance')}
              className="text-sm text-blue-600 hover:text-blue-800 font-medium flex items-center"
            >
              View Heat Map
              <ArrowRight className="h-3 w-3 ml-1" />
            </button>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 hover:shadow-md transition-shadow duration-200">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-red-100">
              <AlertTriangle className="h-6 w-6 text-red-600" />
            </div>
            <div className="ml-4">
              <h3 className="text-sm font-medium text-gray-500">Critical Issues</h3>
              <div className="flex items-center">
                <p className="text-2xl font-bold text-gray-900">{dashboardData.stats.criticalIssues}</p>
                <span className="ml-2 text-sm text-red-600">+1</span>
              </div>
            </div>
          </div>
          <div className="mt-4">
            <button 
              onClick={() => handleViewDetails('critical')}
              className="text-sm text-red-600 hover:text-red-800 font-medium flex items-center"
            >
              View Details
              <ExternalLink className="h-3 w-3 ml-1" />
            </button>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 hover:shadow-md transition-shadow duration-200">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-yellow-100">
              <AlertTriangle className="h-6 w-6 text-yellow-600" />
            </div>
            <div className="ml-4">
              <h3 className="text-sm font-medium text-gray-500">Warnings</h3>
              <div className="flex items-center">
                <p className="text-2xl font-bold text-gray-900">{dashboardData.stats.warningIssues}</p>
                <span className="ml-2 text-sm text-yellow-600">-2</span>
              </div>
            </div>
          </div>
          <div className="mt-4">
            <button 
              onClick={() => handleViewDetails('warnings')}
              className="text-sm text-yellow-600 hover:text-yellow-800 font-medium flex items-center"
            >
              Review All
              <ExternalLink className="h-3 w-3 ml-1" />
            </button>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 hover:shadow-md transition-shadow duration-200">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-green-100">
              <CheckCircle className="h-6 w-6 text-green-600" />
            </div>
            <div className="ml-4">
              <h3 className="text-sm font-medium text-gray-500">Passed Controls</h3>
              <div className="flex items-center">
                <p className="text-2xl font-bold text-gray-900">{dashboardData.stats.passedControls}</p>
                <span className="ml-2 text-sm text-green-600">+3</span>
              </div>
            </div>
          </div>
          <div className="mt-4">
            <div className="text-sm text-gray-500">
              {Math.round((dashboardData.stats.passedControls / dashboardData.stats.totalControls) * 100)}% of total controls
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Controls Overview */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-semibold text-gray-900">Security Controls Overview</h2>
                <Link 
                  to="/compliance"
                  className="text-sm text-blue-600 hover:text-blue-800 font-medium flex items-center"
                >
                  View All Controls
                  <ArrowRight className="h-3 w-3 ml-1" />
                </Link>
              </div>
            </div>
            <div className="p-6">
              <div className="space-y-4">
                {dashboardData.controlsByCategory.map((control, index) => (
                  <button
                    key={index}
                    onClick={() => navigate('/compliance')}
                    className="w-full flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 hover:border-blue-300 transition-all duration-200 text-left"
                  >
                    <div className="flex items-center">
                      <div className={`w-3 h-3 rounded-full mr-3 ${
                        control.status === 'passed' ? 'bg-green-500' :
                        control.status === 'warning' ? 'bg-yellow-500' : 'bg-red-500'
                      }`} />
                      <div>
                        <h3 className="font-medium text-gray-900">{control.name}</h3>
                        <p className="text-sm text-gray-500">{control.issues} issues found</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="text-right">
                        <div className="text-sm font-medium text-gray-900">{control.score}%</div>
                        <div className={`text-xs ${control.trend.startsWith('+') ? 'text-green-600' : 'text-red-600'}`}>
                          {control.trend}
                        </div>
                      </div>
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(control.status)}`}>
                        {control.status}
                      </span>
                      <Eye className="h-4 w-4 text-gray-400" />
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Recent Activity */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-lg font-semibold text-gray-900">Recent Activity</h2>
            </div>
            <div className="p-6">
              <div className="space-y-4">
                {dashboardData.recentActivity.slice(0, 4).map((activity) => (
                  <button
                    key={activity.id}
                    onClick={() => navigate('/activity-logs')}
                    className="w-full flex items-start text-left hover:bg-gray-50 p-2 rounded-lg transition-colors duration-200"
                  >
                    <div className={`p-2 rounded-full mr-3 ${getActivityIcon(activity.severity)}`}>
                      <Activity className="h-4 w-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-gray-900">{activity.message}</p>
                      <p className="text-xs text-gray-500 mt-1">
                        {new Date(activity.time).toLocaleString()} • {activity.user}
                      </p>
                    </div>
                    <ArrowRight className="h-3 w-3 text-gray-400 mt-1" />
                  </button>
                ))}
              </div>
              <div className="mt-4 pt-4 border-t border-gray-200">
                <button 
                  onClick={() => navigate('/activity-logs')}
                  className="text-sm text-blue-600 hover:text-blue-800 font-medium"
                >
                  View All Activity
                </button>
              </div>
            </div>
          </div>

          {/* Upcoming Tasks */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-lg font-semibold text-gray-900">Upcoming Tasks</h2>
            </div>
            <div className="p-6">
              <div className="space-y-3">
                {dashboardData.upcomingTasks.map((task, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between hover:bg-gray-50 p-2 rounded-lg transition-colors duration-200"
                  >
                    <div className="flex-1">
                      <p className="text-sm font-medium text-gray-900">{task.task}</p>
                      <div className="flex items-center mt-1">
                        <Calendar className="h-3 w-3 text-gray-400 mr-1" />
                        <span className="text-xs text-gray-500">Due in {task.due}</span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${getPriorityColor(task.priority)}`}>
                        {task.priority}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-4 pt-4 border-t border-gray-200">
                <button 
                  onClick={() => navigate('/settings?tab=tasks')}
                  className="text-sm text-blue-600 hover:text-blue-800 font-medium"
                >
                  View All Tasks
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}