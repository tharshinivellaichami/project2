import React, { useState, useEffect } from 'react';
import { 
  Filter, 
  Download, 
  AlertTriangle, 
  CheckCircle, 
  XCircle,
  Info,
  Calendar,
  Search,
  ArrowLeft,
  RefreshCw,
  Eye,
  Settings,
  FileText,
  Zap
} from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useToast } from '../hooks/useToast';
import { dashboardAPI } from '../services/api';
import LoadingSpinner from '../components/LoadingSpinner';

interface ComplianceControl {
  id: string;
  name: string;
  status: 'passed' | 'warning' | 'critical';
  score: number;
  lastCheck: string;
  issues: Array<{
    severity: string;
    description: string;
  }>;
}

interface HeatMapData {
  framework: string;
  categories: Record<string, ComplianceControl[]>;
  summary: {
    total: number;
    passed: number;
    warning: number;
    critical: number;
  };
}

export default function ComplianceHeatMap() {
  const [selectedFilter, setSelectedFilter] = useState('all');
  const [selectedControl, setSelectedControl] = useState<ComplianceControl | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const [loading, setLoading] = useState(true);
  const [heatMapData, setHeatMapData] = useState<HeatMapData | null>(null);
  const navigate = useNavigate();
  const { showToast } = useToast();

  useEffect(() => {
    loadHeatMapData();
  }, []);

  const loadHeatMapData = async () => {
    try {
      setLoading(true);
      const response = await dashboardAPI.getComplianceHeatMap('SOC2');
      if (response.success) {
        setHeatMapData(response.data);
      } else {
        showToast('error', 'Failed to load compliance data');
      }
    } catch (error) {
      console.error('Heat map load error:', error);
      showToast('error', 'Failed to load compliance data');
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    showToast('info', 'Refreshing compliance data...');
    
    try {
      await loadHeatMapData();
      showToast('success', 'Compliance data refreshed successfully!');
    } catch (error) {
      showToast('error', 'Failed to refresh compliance data');
    } finally {
      setRefreshing(false);
    }
  };

  const handleExportReport = () => {
    showToast('success', 'Generating compliance report...');
    setTimeout(() => {
      showToast('success', 'Report exported successfully!');
      // Simulate file download
      const link = document.createElement('a');
      link.href = '#';
      link.download = 'compliance-heat-map-report.pdf';
      link.click();
    }, 2000);
  };

  const handleRunAssessment = async () => {
    try {
      showToast('info', 'Starting compliance assessment...');
      const response = await dashboardAPI.runAssessment('SOC2');
      if (response.success) {
        showToast('success', 'Assessment started successfully!');
        // Refresh data after assessment
        setTimeout(() => {
          loadHeatMapData();
        }, 3000);
      }
    } catch (error) {
      showToast('error', 'Failed to start assessment');
    }
  };

  const handleViewRemediation = (control: ComplianceControl) => {
    showToast('info', `Opening remediation steps for ${control.id}...`);
    navigate('/assistant', { state: { control } });
  };

  const handleConfigureControl = (control: ComplianceControl) => {
    showToast('info', `Opening configuration for ${control.id}...`);
    // In a real app, this would open a configuration modal or page
  };

  const handleViewEvidence = (control: ComplianceControl) => {
    showToast('info', `Viewing evidence for ${control.id}...`);
    // In a real app, this would show evidence collection
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'passed': return 'bg-green-500';
      case 'warning': return 'bg-yellow-500';
      case 'critical': return 'bg-red-500';
      default: return 'bg-gray-300';
    }
  };

  const getStatusBorder = (status: string) => {
    switch (status) {
      case 'passed': return 'border-green-200 bg-green-50';
      case 'warning': return 'border-yellow-200 bg-yellow-50';
      case 'critical': return 'border-red-200 bg-red-50';
      default: return 'border-gray-200 bg-gray-50';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'passed': return <CheckCircle className="h-5 w-5 text-green-600" />;
      case 'warning': return <AlertTriangle className="h-5 w-5 text-yellow-600" />;
      case 'critical': return <XCircle className="h-5 w-5 text-red-600" />;
      default: return <Info className="h-5 w-5 text-gray-600" />;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <LoadingSpinner size="lg" />
          <p className="mt-4 text-gray-600">Loading compliance heat map...</p>
        </div>
      </div>
    );
  }

  if (!heatMapData) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <AlertTriangle className="h-12 w-12 text-red-500 mx-auto mb-4" />
          <p className="text-gray-600">Failed to load compliance data</p>
          <button 
            onClick={loadHeatMapData}
            className="mt-4 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors duration-200"
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  const categories = Object.keys(heatMapData.categories);
  
  const filteredControls = selectedFilter === 'all' 
    ? Object.values(heatMapData.categories).flat()
    : Object.values(heatMapData.categories).flat().filter(control => control.status === selectedFilter);

  const statusCounts = heatMapData.summary;

  return (
    <div className="p-6">
      {/* Back Button */}
      <div className="mb-4">
        <Link 
          to="/dashboard" 
          className="flex items-center text-gray-600 hover:text-gray-900 transition-colors duration-200"
        >
          <ArrowLeft className="h-5 w-5 mr-2" />
          Back to Dashboard
        </Link>
      </div>

      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Compliance Heat Map</h1>
            <p className="text-gray-600 mt-2">Visual overview of your {heatMapData.framework} compliance status</p>
          </div>
          <div className="flex items-center space-x-3">
            <button
              onClick={handleRefresh}
              disabled={refreshing}
              className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200 disabled:opacity-50"
            >
              <RefreshCw className={`h-4 w-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
              {refreshing ? 'Refreshing...' : 'Refresh'}
            </button>
            <button
              onClick={handleRunAssessment}
              className="flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors duration-200"
            >
              <Zap className="h-4 w-4 mr-2" />
              Run Assessment
            </button>
          </div>
        </div>
      </div>

      {/* Status Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <button
          onClick={() => setSelectedFilter('all')}
          className={`bg-white p-4 rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-all duration-200 text-left ${selectedFilter === 'all' ? 'ring-2 ring-blue-500' : ''}`}
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Controls</p>
              <p className="text-2xl font-bold text-gray-900">{statusCounts.total}</p>
            </div>
            <Info className="h-8 w-8 text-gray-400" />
          </div>
        </button>
        
        <button
          onClick={() => setSelectedFilter('passed')}
          className={`bg-white p-4 rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-all duration-200 text-left ${selectedFilter === 'passed' ? 'ring-2 ring-green-500' : ''}`}
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Passed</p>
              <p className="text-2xl font-bold text-green-600">{statusCounts.passed}</p>
            </div>
            <CheckCircle className="h-8 w-8 text-green-500" />
          </div>
        </button>
        
        <button
          onClick={() => setSelectedFilter('warning')}
          className={`bg-white p-4 rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-all duration-200 text-left ${selectedFilter === 'warning' ? 'ring-2 ring-yellow-500' : ''}`}
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Warnings</p>
              <p className="text-2xl font-bold text-yellow-600">{statusCounts.warning}</p>
            </div>
            <AlertTriangle className="h-8 w-8 text-yellow-500" />
          </div>
        </button>
        
        <button
          onClick={() => setSelectedFilter('critical')}
          className={`bg-white p-4 rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-all duration-200 text-left ${selectedFilter === 'critical' ? 'ring-2 ring-red-500' : ''}`}
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Critical</p>
              <p className="text-2xl font-bold text-red-600">{statusCounts.critical}</p>
            </div>
            <XCircle className="h-8 w-8 text-red-500" />
          </div>
        </button>
      </div>

      {/* Filters and Actions */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setSelectedFilter('all')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200 ${
              selectedFilter === 'all' 
                ? 'bg-blue-600 text-white' 
                : 'bg-white border border-gray-300 text-gray-700 hover:bg-gray-50'
            }`}
          >
            All Controls
          </button>
          <button
            onClick={() => setSelectedFilter('critical')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200 ${
              selectedFilter === 'critical' 
                ? 'bg-red-600 text-white' 
                : 'bg-white border border-gray-300 text-gray-700 hover:bg-gray-50'
            }`}
          >
            Critical Issues
          </button>
          <button
            onClick={() => setSelectedFilter('warning')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200 ${
              selectedFilter === 'warning' 
                ? 'bg-yellow-600 text-white' 
                : 'bg-white border border-gray-300 text-gray-700 hover:bg-gray-50'
            }`}
          >
            Warnings
          </button>
          <button
            onClick={() => setSelectedFilter('passed')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200 ${
              selectedFilter === 'passed' 
                ? 'bg-green-600 text-white' 
                : 'bg-white border border-gray-300 text-gray-700 hover:bg-gray-50'
            }`}
          >
            Passed
          </button>
        </div>
        
        <div className="flex gap-2">
          <button 
            onClick={handleExportReport}
            className="flex items-center px-4 py-2 bg-white border border-gray-300 rounded-lg text-sm text-gray-700 hover:bg-gray-50 transition-colors duration-200"
          >
            <Download className="h-4 w-4 mr-2" />
            Export Report
          </button>
          <button 
            onClick={() => navigate('/reports')}
            className="flex items-center px-4 py-2 bg-white border border-gray-300 rounded-lg text-sm text-gray-700 hover:bg-gray-50 transition-colors duration-200"
          >
            <FileText className="h-4 w-4 mr-2" />
            View Reports
          </button>
        </div>
      </div>

      {/* Heat Map Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-lg font-semibold text-gray-900">{heatMapData.framework} Controls Heat Map</h2>
            </div>
            <div className="p-6">
              {categories.map(category => (
                <div key={category} className="mb-6 last:mb-0">
                  <h3 className="text-sm font-medium text-gray-700 mb-3">{category}</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                    {heatMapData.categories[category]
                      .filter(control => selectedFilter === 'all' || control.status === selectedFilter)
                      .map(control => (
                        <button
                          key={control.id}
                          onClick={() => setSelectedControl(control)}
                          className={`p-3 rounded-lg border-2 cursor-pointer transition-all duration-200 hover:shadow-md text-left ${getStatusBorder(control.status)}`}
                        >
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-sm font-medium text-gray-900">{control.id}</span>
                            <div className={`w-3 h-3 rounded-full ${getStatusColor(control.status)}`} />
                          </div>
                          <p className="text-xs text-gray-600 mb-2">{control.name}</p>
                          <div className="flex items-center justify-between">
                            <span className="text-xs text-gray-500">Score: {control.score}%</span>
                            {control.issues.length > 0 && (
                              <span className="text-xs text-red-600">{control.issues.length} issues</span>
                            )}
                          </div>
                        </button>
                      ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Control Details Panel */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">Control Details</h2>
          </div>
          <div className="p-6">
            {selectedControl ? (
              <div className="space-y-4">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-semibold text-gray-900">{selectedControl.id}</h3>
                    {getStatusIcon(selectedControl.status)}
                  </div>
                  <p className="text-sm text-gray-600">{selectedControl.name}</p>
                </div>
                
                <div>
                  <label className="text-sm font-medium text-gray-700">Compliance Score</label>
                  <div className="flex items-center mt-1">
                    <div className="flex-1 bg-gray-200 rounded-full h-2 mr-3">
                      <div 
                        className={`h-2 rounded-full ${
                          selectedControl.score >= 80 ? 'bg-green-500' :
                          selectedControl.score >= 60 ? 'bg-yellow-500' : 'bg-red-500'
                        }`}
                        style={{ width: `${selectedControl.score}%` }}
                      />
                    </div>
                    <span className="text-sm font-medium text-gray-900">{selectedControl.score}%</span>
                  </div>
                </div>
                
                <div>
                  <label className="text-sm font-medium text-gray-700">Last Checked</label>
                  <div className="flex items-center mt-1">
                    <Calendar className="h-4 w-4 text-gray-400 mr-2" />
                    <span className="text-sm text-gray-900">{selectedControl.lastCheck}</span>
                  </div>
                </div>
                
                {selectedControl.issues.length > 0 && (
                  <div>
                    <label className="text-sm font-medium text-gray-700">Issues Found</label>
                    <div className="mt-2 space-y-2">
                      {selectedControl.issues.map((issue, index) => (
                        <div key={index} className="flex items-start">
                          <AlertTriangle className="h-4 w-4 text-red-500 mr-2 mt-0.5 flex-shrink-0" />
                          <span className="text-sm text-gray-900">{issue.description}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                
                <div className="pt-4 border-t border-gray-200 space-y-2">
                  <button 
                    onClick={() => handleViewRemediation(selectedControl)}
                    className="w-full bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors duration-200 flex items-center justify-center"
                  >
                    <Zap className="h-4 w-4 mr-2" />
                    View Remediation Steps
                  </button>
                  <button 
                    onClick={() => handleConfigureControl(selectedControl)}
                    className="w-full border border-gray-300 text-gray-700 px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-50 transition-colors duration-200 flex items-center justify-center"
                  >
                    <Settings className="h-4 w-4 mr-2" />
                    Configure Control
                  </button>
                  <button 
                    onClick={() => handleViewEvidence(selectedControl)}
                    className="w-full border border-gray-300 text-gray-700 px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-50 transition-colors duration-200 flex items-center justify-center"
                  >
                    <Eye className="h-4 w-4 mr-2" />
                    View Evidence
                  </button>
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <Info className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">Select a control to view details</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}