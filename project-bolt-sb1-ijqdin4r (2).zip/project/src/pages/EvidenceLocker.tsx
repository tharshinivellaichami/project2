import React, { useState } from 'react';
import { 
  Vault, 
  FileText, 
  Upload, 
  Download, 
  Search, 
  Filter, 
  Eye,
  Lock,
  Unlock,
  Calendar,
  User,
  Tag,
  ArrowLeft,
  RefreshCw,
  Plus,
  MoreVertical,
  Share2,
  Trash2,
  Shield,
  AlertTriangle,
  CheckCircle
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { useToast } from '../hooks/useToast';

interface Evidence {
  id: number;
  name: string;
  type: string;
  category: string;
  uploadedBy: string;
  uploadDate: string;
  size: string;
  status: 'approved' | 'pending' | 'rejected';
  confidentiality: 'public' | 'internal' | 'confidential' | 'restricted';
  tags: string[];
  description: string;
  relatedControls: string[];
  lastAccessed: string;
  accessCount: number;
}

export default function EvidenceLocker() {
  const [evidence, setEvidence] = useState<Evidence[]>([
    {
      id: 1,
      name: 'Information Security Policy v2.1',
      type: 'PDF',
      category: 'Policies',
      uploadedBy: 'sarah.wilson@company.com',
      uploadDate: '2024-01-10',
      size: '2.4 MB',
      status: 'approved',
      confidentiality: 'internal',
      tags: ['SOC2', 'Security Policy', 'CC1.1'],
      description: 'Comprehensive information security policy covering all organizational security requirements',
      relatedControls: ['CC1.1', 'CC1.2', 'CC5.1'],
      lastAccessed: '2024-01-15',
      accessCount: 12
    },
    {
      id: 2,
      name: 'AWS IAM Configuration Report',
      type: 'JSON',
      category: 'Technical Evidence',
      uploadedBy: 'mike.johnson@company.com',
      uploadDate: '2024-01-12',
      size: '856 KB',
      status: 'approved',
      confidentiality: 'confidential',
      tags: ['AWS', 'IAM', 'Access Control', 'CC5.2'],
      description: 'Automated export of AWS IAM roles, policies, and user configurations',
      relatedControls: ['CC5.1', 'CC5.2', 'CC6.1'],
      lastAccessed: '2024-01-14',
      accessCount: 8
    },
    {
      id: 3,
      name: 'Employee Security Training Records',
      type: 'XLSX',
      category: 'Training Records',
      uploadedBy: 'hr@company.com',
      uploadDate: '2024-01-08',
      size: '1.2 MB',
      status: 'pending',
      confidentiality: 'internal',
      tags: ['Training', 'HR', 'CC1.4'],
      description: 'Quarterly security awareness training completion records',
      relatedControls: ['CC1.4'],
      lastAccessed: '2024-01-13',
      accessCount: 5
    },
    {
      id: 4,
      name: 'Incident Response Plan',
      type: 'PDF',
      category: 'Procedures',
      uploadedBy: 'john.doe@company.com',
      uploadDate: '2024-01-05',
      size: '3.1 MB',
      status: 'approved',
      confidentiality: 'restricted',
      tags: ['Incident Response', 'CC7.1', 'Emergency'],
      description: 'Detailed incident response procedures and escalation matrix',
      relatedControls: ['CC7.1', 'CC7.2', 'CC7.3'],
      lastAccessed: '2024-01-11',
      accessCount: 15
    },
    {
      id: 5,
      name: 'Vendor Risk Assessment - CloudProvider',
      type: 'PDF',
      category: 'Risk Assessments',
      uploadedBy: 'compliance@company.com',
      uploadDate: '2024-01-03',
      size: '4.2 MB',
      status: 'approved',
      confidentiality: 'confidential',
      tags: ['Vendor Risk', 'Third Party', 'CC9.1'],
      description: 'Comprehensive risk assessment for primary cloud service provider',
      relatedControls: ['CC9.1', 'CC9.2'],
      lastAccessed: '2024-01-09',
      accessCount: 7
    }
  ]);

  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [showUploadModal, setShowUploadModal] = useState(false);
  const { showToast } = useToast();

  const categories = [
    { id: 'all', name: 'All Categories', count: evidence.length },
    { id: 'Policies', name: 'Policies', count: evidence.filter(e => e.category === 'Policies').length },
    { id: 'Technical Evidence', name: 'Technical Evidence', count: evidence.filter(e => e.category === 'Technical Evidence').length },
    { id: 'Training Records', name: 'Training Records', count: evidence.filter(e => e.category === 'Training Records').length },
    { id: 'Procedures', name: 'Procedures', count: evidence.filter(e => e.category === 'Procedures').length },
    { id: 'Risk Assessments', name: 'Risk Assessments', count: evidence.filter(e => e.category === 'Risk Assessments').length }
  ];

  const filteredEvidence = evidence.filter(item => {
    const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;
    const matchesStatus = selectedStatus === 'all' || item.status === selectedStatus;
    const matchesSearch = searchQuery === '' || 
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    
    return matchesCategory && matchesStatus && matchesSearch;
  });

  const handleUploadEvidence = () => {
    showToast('success', 'Evidence uploaded successfully!');
    setShowUploadModal(false);
  };

  const handleDownloadEvidence = (evidenceItem: Evidence) => {
    showToast('success', `Downloading ${evidenceItem.name}...`);
    // Simulate file download
    const link = document.createElement('a');
    link.href = '#';
    link.download = evidenceItem.name;
    link.click();
  };

  const handleShareEvidence = (evidenceItem: Evidence) => {
    showToast('info', `Generating secure share link for ${evidenceItem.name}...`);
    setTimeout(() => {
      navigator.clipboard.writeText(`https://securosync.com/evidence/shared/${evidenceItem.id}`);
      showToast('success', 'Secure share link copied to clipboard!');
    }, 1000);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved': return 'text-green-600 bg-green-100';
      case 'pending': return 'text-yellow-600 bg-yellow-100';
      case 'rejected': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getConfidentialityColor = (level: string) => {
    switch (level) {
      case 'public': return 'text-blue-600 bg-blue-100';
      case 'internal': return 'text-green-600 bg-green-100';
      case 'confidential': return 'text-yellow-600 bg-yellow-100';
      case 'restricted': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getConfidentialityIcon = (level: string) => {
    switch (level) {
      case 'restricted': return <Lock className="h-3 w-3" />;
      case 'confidential': return <Shield className="h-3 w-3" />;
      default: return <Unlock className="h-3 w-3" />;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'approved': return <CheckCircle className="h-4 w-4" />;
      case 'pending': return <AlertTriangle className="h-4 w-4" />;
      case 'rejected': return <AlertTriangle className="h-4 w-4" />;
      default: return <FileText className="h-4 w-4" />;
    }
  };

  return (
    <div className="p-6">
      {/* Back Button */}
      <div className="mb-4">
        <Link 
          to="/dashboard" 
          className="flex items-center text-gray-600 hover:text-gray-900 transition-colors duration-200"
        >
          <ArrowLeft className="h-5 w-5 mr-2" />
          Back to Dashboard
        </Link>
      </div>

      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Evidence Locker</h1>
            <p className="text-gray-600 mt-2">Secure storage for compliance artifacts and documentation</p>
          </div>
          <div className="flex items-center space-x-3">
            <button
              onClick={() => showToast('info', 'Refreshing evidence locker...')}
              className="flex items-center px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors duration-200"
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              Refresh
            </button>
            <button
              onClick={() => setShowUploadModal(true)}
              className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200"
            >
              <Upload className="h-4 w-4 mr-2" />
              Upload Evidence
            </button>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <div className="flex items-center">
            <Vault className="h-8 w-8 text-blue-600" />
            <div className="ml-4">
              <h3 className="text-lg font-semibold text-gray-900">Total Evidence</h3>
              <p className="text-2xl font-bold text-blue-600">{evidence.length}</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <div className="flex items-center">
            <CheckCircle className="h-8 w-8 text-green-600" />
            <div className="ml-4">
              <h3 className="text-lg font-semibold text-gray-900">Approved</h3>
              <p className="text-2xl font-bold text-green-600">
                {evidence.filter(e => e.status === 'approved').length}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <div className="flex items-center">
            <AlertTriangle className="h-8 w-8 text-yellow-600" />
            <div className="ml-4">
              <h3 className="text-lg font-semibold text-gray-900">Pending Review</h3>
              <p className="text-2xl font-bold text-yellow-600">
                {evidence.filter(e => e.status === 'pending').length}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <div className="flex items-center">
            <Lock className="h-8 w-8 text-red-600" />
            <div className="ml-4">
              <h3 className="text-lg font-semibold text-gray-900">Restricted</h3>
              <p className="text-2xl font-bold text-red-600">
                {evidence.filter(e => e.confidentiality === 'restricted').length}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 mb-8">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Filter Evidence</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Search</label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search evidence..."
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Category</label>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                {categories.map(category => (
                  <option key={category.id} value={category.id}>
                    {category.name} ({category.count})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Status</label>
              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="all">All Status</option>
                <option value="approved">Approved</option>
                <option value="pending">Pending</option>
                <option value="rejected">Rejected</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Evidence Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredEvidence.map((item) => (
          <div key={item.id} className="bg-white rounded-xl shadow-sm border border-gray-200 hover:shadow-md transition-all duration-200">
            <div className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center mr-3">
                    <FileText className="h-5 w-5 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 text-sm">{item.name}</h3>
                    <p className="text-xs text-gray-500">{item.type} • {item.size}</p>
                  </div>
                </div>
                <div className="relative">
                  <button className="p-1 text-gray-400 hover:text-gray-600 rounded transition-colors duration-200">
                    <MoreVertical className="h-4 w-4" />
                  </button>
                </div>
              </div>

              <p className="text-sm text-gray-600 mb-4 line-clamp-2">{item.description}</p>

              <div className="space-y-3 mb-4">
                <div className="flex items-center justify-between">
                  <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(item.status)}`}>
                    {getStatusIcon(item.status)}
                    <span className="ml-1 capitalize">{item.status}</span>
                  </span>
                  <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getConfidentialityColor(item.confidentiality)}`}>
                    {getConfidentialityIcon(item.confidentiality)}
                    <span className="ml-1 capitalize">{item.confidentiality}</span>
                  </span>
                </div>

                <div className="flex flex-wrap gap-1">
                  {item.tags.slice(0, 3).map((tag, index) => (
                    <span key={index} className="inline-flex items-center px-2 py-1 rounded text-xs bg-gray-100 text-gray-700">
                      <Tag className="h-3 w-3 mr-1" />
                      {tag}
                    </span>
                  ))}
                  {item.tags.length > 3 && (
                    <span className="inline-flex items-center px-2 py-1 rounded text-xs bg-gray-100 text-gray-700">
                      +{item.tags.length - 3} more
                    </span>
                  )}
                </div>

                <div className="text-xs text-gray-500 space-y-1">
                  <div className="flex items-center">
                    <User className="h-3 w-3 mr-1" />
                    Uploaded by {item.uploadedBy}
                  </div>
                  <div className="flex items-center">
                    <Calendar className="h-3 w-3 mr-1" />
                    {item.uploadDate} • Accessed {item.accessCount} times
                  </div>
                </div>
              </div>

              <div className="flex space-x-2">
                <button 
                  onClick={() => showToast('info', `Opening ${item.name}...`)}
                  className="flex-1 bg-blue-600 text-white px-3 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors duration-200 flex items-center justify-center"
                >
                  <Eye className="h-4 w-4 mr-1" />
                  View
                </button>
                <button 
                  onClick={() => handleDownloadEvidence(item)}
                  className="px-3 py-2 border border-gray-300 text-gray-700 rounded-lg text-sm hover:bg-gray-50 transition-colors duration-200"
                >
                  <Download className="h-4 w-4" />
                </button>
                <button 
                  onClick={() => handleShareEvidence(item)}
                  className="px-3 py-2 border border-gray-300 text-gray-700 rounded-lg text-sm hover:bg-gray-50 transition-colors duration-200"
                >
                  <Share2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredEvidence.length === 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
          <Vault className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No evidence found</h3>
          <p className="text-gray-600 mb-4">Try adjusting your filters or upload new evidence.</p>
          <button 
            onClick={() => setShowUploadModal(true)}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors duration-200"
          >
            Upload Evidence
          </button>
        </div>
      )}

      {/* Upload Modal */}
      {showUploadModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Upload Evidence</h3>
            
            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">File</label>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                  <Upload className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                  <p className="text-sm text-gray-600">Drop files here or click to browse</p>
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Category</label>
                <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                  <option value="Policies">Policies</option>
                  <option value="Technical Evidence">Technical Evidence</option>
                  <option value="Training Records">Training Records</option>
                  <option value="Procedures">Procedures</option>
                  <option value="Risk Assessments">Risk Assessments</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Confidentiality Level</label>
                <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                  <option value="public">Public</option>
                  <option value="internal">Internal</option>
                  <option value="confidential">Confidential</option>
                  <option value="restricted">Restricted</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                <textarea
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Describe this evidence..."
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Tags</label>
                <input
                  type="text"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Enter tags separated by commas"
                />
              </div>
            </div>

            <div className="flex space-x-3">
              <button
                onClick={() => setShowUploadModal(false)}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors duration-200"
              >
                Cancel
              </button>
              <button
                onClick={handleUploadEvidence}
                className="flex-1 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors duration-200"
              >
                Upload
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}