import React, { useState } from 'react';
import { 
  FileText, 
  Download, 
  Calendar, 
  Filter, 
  Eye, 
  Share2,
  Clock,
  CheckCircle,
  AlertTriangle,
  TrendingUp,
  Plus,
  Loader,
  ArrowLeft,
  Trash2,
  RefreshCw,
  ExternalLink
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { useToast } from '../hooks/useToast';

interface Report {
  id: number;
  name: string;
  type: string;
  status: 'ready' | 'generating' | 'failed';
  generated: string;
  size: string;
  pages: number;
  complianceScore: number;
  criticalIssues: number;
  warnings: number;
  description: string;
}

export default function Reports() {
  const [selectedReport, setSelectedReport] = useState<Report | null>(null);
  const [showGenerateModal, setShowGenerateModal] = useState(false);
  const [generatingReport, setGeneratingReport] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const { showToast } = useToast();

  const [reports, setReports] = useState<Report[]>([
    {
      id: 1,
      name: 'SOC 2 Type I Readiness Report',
      type: 'SOC2',
      status: 'ready',
      generated: '2024-01-15',
      size: '2.4 MB',
      pages: 45,
      complianceScore: 78,
      criticalIssues: 3,
      warnings: 12,
      description: 'Comprehensive assessment of current SOC 2 compliance posture with detailed findings and remediation recommendations.'
    },
    {
      id: 2,
      name: 'Monthly Security Assessment',
      type: 'Security',
      status: 'generating',
      generated: '2024-01-14',
      size: '1.8 MB',
      pages: 32,
      complianceScore: 82,
      criticalIssues: 2,
      warnings: 8,
      description: 'Regular monthly security posture assessment covering all integrated systems and security controls.'
    },
    {
      id: 3,
      name: 'AWS Infrastructure Review',
      type: 'Infrastructure',
      status: 'ready',
      generated: '2024-01-12',
      size: '3.1 MB',
      pages: 58,
      complianceScore: 85,
      criticalIssues: 1,
      warnings: 6,
      description: 'Detailed analysis of AWS infrastructure compliance with security best practices and recommendations.'
    },
    {
      id: 4,
      name: 'Quarterly Compliance Summary',
      type: 'Compliance',
      status: 'ready',
      generated: '2024-01-01',
      size: '4.2 MB',
      pages: 72,
      complianceScore: 76,
      criticalIssues: 5,
      warnings: 18,
      description: 'Comprehensive quarterly review of compliance status across all frameworks and systems.'
    }
  ]);

  const handleGenerateReport = (templateName: string) => {
    setGeneratingReport(true);
    setShowGenerateModal(false);
    showToast('info', `Generating ${templateName}...`);

    // Create new report
    const newReport: Report = {
      id: reports.length + 1,
      name: templateName,
      type: templateName.includes('SOC') ? 'SOC2' : 'Security',
      status: 'generating',
      generated: new Date().toISOString().split('T')[0],
      size: '0 MB',
      pages: 0,
      complianceScore: 0,
      criticalIssues: 0,
      warnings: 0,
      description: `Generating ${templateName}...`
    };

    setReports(prev => [newReport, ...prev]);

    // Simulate report generation
    setTimeout(() => {
      setReports(prev => prev.map(report => 
        report.id === newReport.id 
          ? {
              ...report,
              status: 'ready' as const,
              size: `${(Math.random() * 3 + 1).toFixed(1)} MB`,
              pages: Math.floor(Math.random() * 50) + 20,
              complianceScore: Math.floor(Math.random() * 30) + 70,
              criticalIssues: Math.floor(Math.random() * 5),
              warnings: Math.floor(Math.random() * 15) + 5,
              description: `Complete ${templateName} with detailed findings and recommendations.`
            }
          : report
      ));
      setGeneratingReport(false);
      showToast('success', `${templateName} generated successfully!`);
    }, 5000);
  };

  const handleDownload = (report: Report) => {
    showToast('success', `Downloading ${report.name}...`);
    
    // Simulate download
    const link = document.createElement('a');
    link.href = '#';
    link.download = `${report.name.replace(/\s+/g, '_')}.pdf`;
    link.click();
    
    setTimeout(() => {
      showToast('success', 'Download completed!');
    }, 2000);
  };

  const handleShare = (report: Report) => {
    showToast('info', `Generating shareable link for ${report.name}...`);
    
    setTimeout(() => {
      // Simulate copying share link to clipboard
      navigator.clipboard.writeText(`https://securosync.com/reports/shared/${report.id}`);
      showToast('success', 'Share link copied to clipboard!');
    }, 1000);
  };

  const handleViewOnline = (report: Report) => {
    showToast('info', `Opening ${report.name} in viewer...`);
    // In a real app, this would open the report in a viewer
  };

  const handleDeleteReport = (reportId: number) => {
    const report = reports.find(r => r.id === reportId);
    if (report) {
      setReports(prev => prev.filter(r => r.id !== reportId));
      showToast('success', `${report.name} deleted successfully`);
      if (selectedReport?.id === reportId) {
        setSelectedReport(null);
      }
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    showToast('info', 'Refreshing reports...');
    
    // Simulate refresh
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setRefreshing(false);
    showToast('success', 'Reports refreshed successfully!');
  };

  const handleScheduleReport = (report: Report) => {
    showToast('info', `Setting up schedule for ${report.name}...`);
    // In a real app, this would open a scheduling modal
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'ready': return 'text-green-600 bg-green-100';
      case 'generating': return 'text-blue-600 bg-blue-100';
      case 'failed': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'ready': return <CheckCircle className="h-4 w-4" />;
      case 'generating': return <Loader className="h-4 w-4 animate-spin" />;
      case 'failed': return <AlertTriangle className="h-4 w-4" />;
      default: return <FileText className="h-4 w-4" />;
    }
  };

  const reportTemplates = [
    { name: 'SOC 2 Type II Assessment', description: 'Full SOC 2 Type II compliance report' },
    { name: 'ISO 27001 Gap Analysis', description: 'Identify gaps in ISO 27001 compliance' },
    { name: 'HIPAA Compliance Review', description: 'Healthcare data protection assessment' },
    { name: 'Custom Security Audit', description: 'Tailored security assessment report' }
  ];

  return (
    <div className="p-6">
      {/* Back Button */}
      <div className="mb-4">
        <Link 
          to="/dashboard" 
          className="flex items-center text-gray-600 hover:text-gray-900 transition-colors duration-200"
        >
          <ArrowLeft className="h-5 w-5 mr-2" />
          Back to Dashboard
        </Link>
      </div>

      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Compliance Reports</h1>
            <p className="text-gray-600 mt-2">Generated compliance reports and audit documentation</p>
          </div>
          <div className="flex items-center space-x-3">
            <button
              onClick={handleRefresh}
              disabled={refreshing}
              className="flex items-center px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors duration-200 disabled:opacity-50"
            >
              <RefreshCw className={`h-4 w-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
              {refreshing ? 'Refreshing...' : 'Refresh'}
            </button>
            <button
              onClick={() => setShowGenerateModal(true)}
              className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200"
            >
              <Plus className="h-4 w-4 mr-2" />
              New Report
            </button>
          </div>
        </div>
      </div>

      {/* Report Generation */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 mb-8">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-gray-900">Generate New Report</h2>
            <button
              onClick={() => setShowGenerateModal(true)}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors duration-200 flex items-center"
            >
              <Plus className="h-4 w-4 mr-2" />
              New Report
            </button>
          </div>
        </div>
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {reportTemplates.map((template, index) => (
              <button
                key={index}
                className="p-4 border border-gray-200 rounded-lg hover:border-blue-300 hover:bg-blue-50 cursor-pointer transition-all duration-200 text-left"
                onClick={() => handleGenerateReport(template.name)}
              >
                <div className="flex items-center mb-3">
                  <FileText className="h-5 w-5 text-blue-600 mr-2" />
                  <h3 className="font-medium text-gray-900">{template.name}</h3>
                </div>
                <p className="text-sm text-gray-600 mb-3">{template.description}</p>
                <div className="w-full bg-blue-600 text-white px-3 py-2 rounded text-sm font-medium hover:bg-blue-700 transition-colors duration-200 text-center">
                  Generate Report
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Generate Modal */}
      {showGenerateModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Generate Custom Report</h3>
            
            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Report Name</label>
                <input
                  type="text"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Enter report name"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Report Type</label>
                <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                  <option>SOC 2 Assessment</option>
                  <option>ISO 27001 Audit</option>
                  <option>HIPAA Review</option>
                  <option>Security Assessment</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Include Sections</label>
                <div className="space-y-2">
                  <label className="flex items-center">
                    <input type="checkbox" defaultChecked className="h-4 w-4 text-blue-600 rounded border-gray-300" />
                    <span className="ml-2 text-sm text-gray-700">Executive Summary</span>
                  </label>
                  <label className="flex items-center">
                    <input type="checkbox" defaultChecked className="h-4 w-4 text-blue-600 rounded border-gray-300" />
                    <span className="ml-2 text-sm text-gray-700">Control Assessment</span>
                  </label>
                  <label className="flex items-center">
                    <input type="checkbox" defaultChecked className="h-4 w-4 text-blue-600 rounded border-gray-300" />
                    <span className="ml-2 text-sm text-gray-700">Remediation Plan</span>
                  </label>
                </div>
              </div>
            </div>

            <div className="flex space-x-3">
              <button
                onClick={() => setShowGenerateModal(false)}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors duration-200"
              >
                Cancel
              </button>
              <button
                onClick={() => handleGenerateReport('Custom Report')}
                className="flex-1 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors duration-200"
              >
                Generate
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reports List */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-semibold text-gray-900">Recent Reports</h2>
                <div className="flex items-center space-x-2">
                  <button className="flex items-center px-3 py-2 text-sm text-gray-600 hover:text-gray-900 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors duration-200">
                    <Filter className="h-4 w-4 mr-1" />
                    Filter
                  </button>
                  <button className="flex items-center px-3 py-2 text-sm text-gray-600 hover:text-gray-900 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors duration-200">
                    <Calendar className="h-4 w-4 mr-1" />
                    Date Range
                  </button>
                </div>
              </div>
            </div>
            <div className="divide-y divide-gray-200">
              {reports.map((report) => (
                <div
                  key={report.id}
                  className="p-6 hover:bg-gray-50 transition-colors duration-200"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center mb-2">
                        <h3 className="font-semibold text-gray-900 mr-3">{report.name}</h3>
                        <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(report.status)}`}>
                          {getStatusIcon(report.status)}
                          <span className="ml-1 capitalize">{report.status}</span>
                        </span>
                      </div>
                      <p className="text-sm text-gray-600 mb-3">{report.description}</p>
                      <div className="flex items-center text-sm text-gray-500 space-x-4">
                        <span>Generated: {report.generated}</span>
                        <span>{report.pages} pages</span>
                        <span>{report.size}</span>
                      </div>
                    </div>
                    <div className="flex flex-col items-end ml-4">
                      <div className="flex items-center mb-2">
                        <TrendingUp className="h-4 w-4 text-blue-600 mr-1" />
                        <span className="text-sm font-medium text-gray-900">{report.complianceScore}%</span>
                      </div>
                      <div className="flex space-x-1">
                        {report.status === 'ready' && (
                          <>
                            <button 
                              onClick={() => setSelectedReport(report)}
                              className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded transition-colors duration-200"
                              title="View details"
                            >
                              <Eye className="h-4 w-4" />
                            </button>
                            <button 
                              onClick={() => handleDownload(report)}
                              className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded transition-colors duration-200"
                              title="Download"
                            >
                              <Download className="h-4 w-4" />
                            </button>
                            <button 
                              onClick={() => handleShare(report)}
                              className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded transition-colors duration-200"
                              title="Share"
                            >
                              <Share2 className="h-4 w-4" />
                            </button>
                            <button 
                              onClick={() => handleDeleteReport(report.id)}
                              className="p-2 text-red-600 hover:text-red-800 hover:bg-red-50 rounded transition-colors duration-200"
                              title="Delete"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Report Details Panel */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">Report Details</h2>
          </div>
          <div className="p-6">
            {selectedReport ? (
              <div className="space-y-6">
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">{selectedReport.name}</h3>
                  <p className="text-sm text-gray-600">{selectedReport.description}</p>
                </div>

                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Status</span>
                    <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(selectedReport.status)}`}>
                      {getStatusIcon(selectedReport.status)}
                      <span className="ml-1 capitalize">{selectedReport.status}</span>
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Generated</span>
                    <span className="text-sm text-gray-900">{selectedReport.generated}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Pages</span>
                    <span className="text-sm text-gray-900">{selectedReport.pages}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">File Size</span>
                    <span className="text-sm text-gray-900">{selectedReport.size}</span>
                  </div>
                </div>

                <div>
                  <h4 className="font-medium text-gray-900 mb-3">Compliance Summary</h4>
                  <div className="space-y-3">
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm text-gray-600">Overall Score</span>
                        <span className="text-sm font-medium text-gray-900">{selectedReport.complianceScore}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className={`h-2 rounded-full ${
                            selectedReport.complianceScore >= 80 ? 'bg-green-500' :
                            selectedReport.complianceScore >= 60 ? 'bg-yellow-500' : 'bg-red-500'
                          }`}
                          style={{ width: `${selectedReport.complianceScore}%` }}
                        />
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center p-3 bg-red-50 rounded-lg">
                        <div className="text-2xl font-bold text-red-600">{selectedReport.criticalIssues}</div>
                        <div className="text-xs text-red-600">Critical Issues</div>
                      </div>
                      <div className="text-center p-3 bg-yellow-50 rounded-lg">
                        <div className="text-2xl font-bold text-yellow-600">{selectedReport.warnings}</div>
                        <div className="text-xs text-yellow-600">Warnings</div>
                      </div>
                    </div>
                  </div>
                </div>

                {selectedReport.status === 'ready' && (
                  <div className="space-y-2">
                    <button 
                      onClick={() => handleDownload(selectedReport)}
                      className="w-full bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors duration-200 flex items-center justify-center"
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Download PDF
                    </button>
                    <button 
                      onClick={() => handleViewOnline(selectedReport)}
                      className="w-full border border-gray-300 text-gray-700 px-4 py-2 rounded-lg font-medium hover:bg-gray-50 transition-colors duration-200 flex items-center justify-center"
                    >
                      <ExternalLink className="h-4 w-4 mr-2" />
                      View Online
                    </button>
                    <button 
                      onClick={() => handleShare(selectedReport)}
                      className="w-full border border-gray-300 text-gray-700 px-4 py-2 rounded-lg font-medium hover:bg-gray-50 transition-colors duration-200 flex items-center justify-center"
                    >
                      <Share2 className="h-4 w-4 mr-2" />
                      Share Report
                    </button>
                    <button 
                      onClick={() => handleScheduleReport(selectedReport)}
                      className="w-full border border-gray-300 text-gray-700 px-4 py-2 rounded-lg font-medium hover:bg-gray-50 transition-colors duration-200 flex items-center justify-center"
                    >
                      <Calendar className="h-4 w-4 mr-2" />
                      Schedule Report
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center py-8">
                <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">Select a report to view details</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}