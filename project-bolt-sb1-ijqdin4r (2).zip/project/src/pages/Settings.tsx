import React, { useState } from 'react';
import { 
  User, 
  Shield, 
  Bell, 
  Key, 
  Building, 
  Globe, 
  Save,
  AlertTriangle,
  CheckCircle,
  Eye,
  EyeOff,
  ArrowLeft,
  RefreshCw,
  Download,
  Upload,
  Trash2
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../hooks/useToast';

export default function Settings() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('profile');
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle');
  const { showToast } = useToast();

  const [profileData, setProfileData] = useState({
    name: user?.name || '',
    email: user?.email || '',
    role: user?.role || '',
    company: user?.company || '',
    phone: '',
    timezone: 'UTC-5'
  });

  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });

  const [notifications, setNotifications] = useState({
    emailAlerts: true,
    criticalIssues: true,
    weeklyReports: true,
    complianceUpdates: false,
    systemMaintenance: true
  });

  const [complianceSettings, setComplianceSettings] = useState({
    primaryFramework: 'SOC2',
    autoRemediation: false,
    riskTolerance: 'medium',
    auditFrequency: 'weekly'
  });

  const tabs = [
    { id: 'profile', name: 'Profile', icon: User },
    { id: 'security', name: 'Security', icon: Shield },
    { id: 'notifications', name: 'Notifications', icon: Bell },
    { id: 'compliance', name: 'Compliance', icon: CheckCircle },
    { id: 'organization', name: 'Organization', icon: Building }
  ];

  const handleProfileUpdate = (field: string, value: string) => {
    setProfileData(prev => ({ ...prev, [field]: value }));
  };

  const handlePasswordUpdate = (field: string, value: string) => {
    setPasswordData(prev => ({ ...prev, [field]: value }));
  };

  const handleNotificationToggle = (setting: string) => {
    setNotifications(prev => ({ ...prev, [setting]: !prev[setting as keyof typeof prev] }));
  };

  const handleComplianceUpdate = (field: string, value: string | boolean) => {
    setComplianceSettings(prev => ({ ...prev, [field]: value }));
  };

  const handleSave = async (section: string) => {
    setSaveStatus('saving');
    showToast('info', `Saving ${section} settings...`);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    setSaveStatus('saved');
    showToast('success', `${section} settings saved successfully!`);
    setTimeout(() => setSaveStatus('idle'), 2000);
  };

  const handlePasswordChange = async () => {
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      showToast('error', 'New passwords do not match');
      return;
    }
    
    if (passwordData.newPassword.length < 6) {
      showToast('error', 'Password must be at least 6 characters');
      return;
    }

    setSaveStatus('saving');
    showToast('info', 'Updating password...');
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    setSaveStatus('saved');
    setPasswordData({ currentPassword: '', newPassword: '', confirmPassword: '' });
    showToast('success', 'Password updated successfully!');
    setTimeout(() => setSaveStatus('idle'), 2000);
  };

  const handleExportData = () => {
    showToast('info', 'Preparing data export...');
    setTimeout(() => {
      showToast('success', 'Data export ready for download!');
      // Simulate file download
      const link = document.createElement('a');
      link.href = '#';
      link.download = 'securosync-data-export.json';
      link.click();
    }, 2000);
  };

  const handleImportData = () => {
    showToast('info', 'Opening file selector...');
    // In a real app, this would open a file input
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = () => {
      showToast('success', 'Data imported successfully!');
    };
    input.click();
  };

  const handleResetSettings = () => {
    if (confirm('Are you sure you want to reset all settings to default? This action cannot be undone.')) {
      showToast('info', 'Resetting settings...');
      setTimeout(() => {
        showToast('success', 'Settings reset to default values');
      }, 1000);
    }
  };

  const handleTestNotifications = () => {
    showToast('info', 'Sending test notification...');
    setTimeout(() => {
      showToast('success', 'Test notification sent! Check your email.');
    }, 1000);
  };

  const handleEnable2FA = () => {
    showToast('info', 'Opening 2FA setup wizard...');
    // In a real app, this would open a 2FA setup modal
  };

  const getSaveButtonText = () => {
    switch (saveStatus) {
      case 'saving': return 'Saving...';
      case 'saved': return 'Saved!';
      case 'error': return 'Error - Try Again';
      default: return 'Save Changes';
    }
  };

  const getSaveButtonClass = () => {
    const baseClass = "bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors duration-200 flex items-center disabled:opacity-50 disabled:cursor-not-allowed";
    
    switch (saveStatus) {
      case 'saved': return baseClass.replace('bg-blue-600 hover:bg-blue-700', 'bg-green-600 hover:bg-green-700');
      case 'error': return baseClass.replace('bg-blue-600 hover:bg-blue-700', 'bg-red-600 hover:bg-red-700');
      default: return baseClass;
    }
  };

  return (
    <div className="p-6">
      {/* Back Button */}
      <div className="mb-4">
        <Link 
          to="/dashboard" 
          className="flex items-center text-gray-600 hover:text-gray-900 transition-colors duration-200"
        >
          <ArrowLeft className="h-5 w-5 mr-2" />
          Back to Dashboard
        </Link>
      </div>

      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Settings</h1>
        <p className="text-gray-600 mt-2">Manage your account, security, and compliance preferences</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Settings Navigation */}
        <div className="lg:col-span-1">
          <nav className="space-y-1">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`w-full flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors duration-200 ${
                    activeTab === tab.id
                      ? 'bg-blue-100 text-blue-700'
                      : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                  }`}
                >
                  <Icon className="h-5 w-5 mr-3" />
                  {tab.name}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Settings Content */}
        <div className="lg:col-span-3">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200">
            {/* Profile Settings */}
            {activeTab === 'profile' && (
              <div className="p-6">
                <h2 className="text-lg font-semibold text-gray-900 mb-6">Profile Information</h2>
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Full Name
                      </label>
                      <input
                        type="text"
                        value={profileData.name}
                        onChange={(e) => handleProfileUpdate('name', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Email Address
                      </label>
                      <input
                        type="email"
                        value={profileData.email}
                        onChange={(e) => handleProfileUpdate('email', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Job Title
                      </label>
                      <input
                        type="text"
                        value={profileData.role}
                        onChange={(e) => handleProfileUpdate('role', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Phone Number
                      </label>
                      <input
                        type="text"
                        value={profileData.phone}
                        onChange={(e) => handleProfileUpdate('phone', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="+1 (555) 123-4567"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Company
                      </label>
                      <input
                        type="text"
                        value={profileData.company}
                        onChange={(e) => handleProfileUpdate('company', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Timezone
                      </label>
                      <select
                        value={profileData.timezone}
                        onChange={(e) => handleProfileUpdate('timezone', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      >
                        <option value="UTC-8">Pacific Time (UTC-8)</option>
                        <option value="UTC-7">Mountain Time (UTC-7)</option>
                        <option value="UTC-6">Central Time (UTC-6)</option>
                        <option value="UTC-5">Eastern Time (UTC-5)</option>
                        <option value="UTC+0">UTC</option>
                      </select>
                    </div>
                  </div>
                  <div className="pt-4 border-t border-gray-200 flex space-x-3">
                    <button 
                      onClick={() => handleSave('profile')}
                      disabled={saveStatus === 'saving'}
                      className={getSaveButtonClass()}
                    >
                      <Save className="h-4 w-4 mr-2" />
                      {getSaveButtonText()}
                    </button>
                    <button 
                      onClick={handleExportData}
                      className="border border-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-50 transition-colors duration-200 flex items-center"
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Export Data
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Security Settings */}
            {activeTab === 'security' && (
              <div className="p-6">
                <h2 className="text-lg font-semibold text-gray-900 mb-6">Security Settings</h2>
                <div className="space-y-8">
                  {/* Password Change */}
                  <div>
                    <h3 className="text-md font-medium text-gray-900 mb-4">Change Password</h3>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Current Password
                        </label>
                        <div className="relative">
                          <input
                            type={showCurrentPassword ? 'text' : 'password'}
                            value={passwordData.currentPassword}
                            onChange={(e) => handlePasswordUpdate('currentPassword', e.target.value)}
                            className="w-full px-3 py-2 pr-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                          />
                          <button
                            type="button"
                            onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                            className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                          >
                            {showCurrentPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                          </button>
                        </div>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          New Password
                        </label>
                        <div className="relative">
                          <input
                            type={showNewPassword ? 'text' : 'password'}
                            value={passwordData.newPassword}
                            onChange={(e) => handlePasswordUpdate('newPassword', e.target.value)}
                            className="w-full px-3 py-2 pr-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                          />
                          <button
                            type="button"
                            onClick={() => setShowNewPassword(!showNewPassword)}
                            className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                          >
                            {showNewPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                          </button>
                        </div>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Confirm New Password
                        </label>
                        <input
                          type="password"
                          value={passwordData.confirmPassword}
                          onChange={(e) => handlePasswordUpdate('confirmPassword', e.target.value)}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        />
                      </div>
                      <button 
                        onClick={handlePasswordChange}
                        disabled={saveStatus === 'saving'}
                        className={getSaveButtonClass()}
                      >
                        {getSaveButtonText()}
                      </button>
                    </div>
                  </div>

                  {/* Two-Factor Authentication */}
                  <div className="pt-6 border-t border-gray-200">
                    <h3 className="text-md font-medium text-gray-900 mb-4">Two-Factor Authentication</h3>
                    <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                      <div>
                        <h4 className="font-medium text-gray-900">Authenticator App</h4>
                        <p className="text-sm text-gray-600">Use an authenticator app to generate codes</p>
                      </div>
                      <button 
                        onClick={handleEnable2FA}
                        className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors duration-200"
                      >
                        Enable
                      </button>
                    </div>
                  </div>

                  {/* Data Management */}
                  <div className="pt-6 border-t border-gray-200">
                    <h3 className="text-md font-medium text-gray-900 mb-4">Data Management</h3>
                    <div className="space-y-3">
                      <button 
                        onClick={handleImportData}
                        className="w-full flex items-center justify-center px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors duration-200"
                      >
                        <Upload className="h-4 w-4 mr-2" />
                        Import Settings
                      </button>
                      <button 
                        onClick={handleResetSettings}
                        className="w-full flex items-center justify-center px-4 py-2 border border-red-300 text-red-600 rounded-lg hover:bg-red-50 transition-colors duration-200"
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Reset All Settings
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Notification Settings */}
            {activeTab === 'notifications' && (
              <div className="p-6">
                <h2 className="text-lg font-semibold text-gray-900 mb-6">Notification Preferences</h2>
                <div className="space-y-6">
                  <div className="space-y-4">
                    {Object.entries(notifications).map(([key, value]) => {
                      const labels = {
                        emailAlerts: { title: 'Email Alerts', desc: 'Receive email notifications for important events' },
                        criticalIssues: { title: 'Critical Issues', desc: 'Get notified immediately for critical compliance issues' },
                        weeklyReports: { title: 'Weekly Reports', desc: 'Receive weekly compliance summary reports' },
                        complianceUpdates: { title: 'Compliance Updates', desc: 'Stay informed about regulatory changes and updates' },
                        systemMaintenance: { title: 'System Maintenance', desc: 'Get notified about scheduled maintenance windows' }
                      };

                      return (
                        <div key={key} className="flex items-center justify-between py-3">
                          <div>
                            <h3 className="font-medium text-gray-900">{labels[key as keyof typeof labels].title}</h3>
                            <p className="text-sm text-gray-600">{labels[key as keyof typeof labels].desc}</p>
                          </div>
                          <label className="relative inline-flex items-center cursor-pointer">
                            <input
                              type="checkbox"
                              checked={value}
                              onChange={() => handleNotificationToggle(key)}
                              className="sr-only peer"
                            />
                            <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                          </label>
                        </div>
                      );
                    })}
                  </div>
                  <div className="pt-4 border-t border-gray-200 flex space-x-3">
                    <button 
                      onClick={() => handleSave('notifications')}
                      disabled={saveStatus === 'saving'}
                      className={getSaveButtonClass()}
                    >
                      <Save className="h-4 w-4 mr-2" />
                      {getSaveButtonText()}
                    </button>
                    <button 
                      onClick={handleTestNotifications}
                      className="border border-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-50 transition-colors duration-200 flex items-center"
                    >
                      <Bell className="h-4 w-4 mr-2" />
                      Test Notifications
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Compliance Settings */}
            {activeTab === 'compliance' && (
              <div className="p-6">
                <h2 className="text-lg font-semibold text-gray-900 mb-6">Compliance Configuration</h2>
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Primary Compliance Framework
                    </label>
                    <select
                      value={complianceSettings.primaryFramework}
                      onChange={(e) => handleComplianceUpdate('primaryFramework', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      <option value="SOC2">SOC 2</option>
                      <option value="ISO27001">ISO 27001</option>
                      <option value="HIPAA">HIPAA</option>
                      <option value="GDPR">GDPR</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Risk Tolerance Level
                    </label>
                    <select
                      value={complianceSettings.riskTolerance}
                      onChange={(e) => handleComplianceUpdate('riskTolerance', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      <option value="low">Low - Strict compliance requirements</option>
                      <option value="medium">Medium - Balanced approach</option>
                      <option value="high">High - Flexible with documented exceptions</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Audit Frequency
                    </label>
                    <select
                      value={complianceSettings.auditFrequency}
                      onChange={(e) => handleComplianceUpdate('auditFrequency', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      <option value="daily">Daily</option>
                      <option value="weekly">Weekly</option>
                      <option value="monthly">Monthly</option>
                    </select>
                  </div>

                  <div className="flex items-center justify-between py-3 border-t border-gray-200">
                    <div>
                      <h3 className="font-medium text-gray-900">Auto-Remediation</h3>
                      <p className="text-sm text-gray-600">Automatically fix certain compliance issues when possible</p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={complianceSettings.autoRemediation}
                        onChange={() => handleComplianceUpdate('autoRemediation', !complianceSettings.autoRemediation)}
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                    </label>
                  </div>

                  <div className="pt-4 border-t border-gray-200">
                    <button 
                      onClick={() => handleSave('compliance')}
                      disabled={saveStatus === 'saving'}
                      className={getSaveButtonClass()}
                    >
                      <Save className="h-4 w-4 mr-2" />
                      {getSaveButtonText()}
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Organization Settings */}
            {activeTab === 'organization' && (
              <div className="p-6">
                <h2 className="text-lg font-semibold text-gray-900 mb-6">Organization Settings</h2>
                <div className="space-y-6">
                  <div>
                    <h3 className="text-md font-medium text-gray-900 mb-4">Company Information</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Company Name
                        </label>
                        <input
                          type="text"
                          value={profileData.company}
                          onChange={(e) => handleProfileUpdate('company', e.target.value)}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Industry
                        </label>
                        <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                          <option>Technology</option>
                          <option>Healthcare</option>
                          <option>Financial Services</option>
                          <option>Manufacturing</option>
                          <option>Other</option>
                        </select>
                      </div>
                    </div>
                  </div>

                  <div className="pt-6 border-t border-gray-200">
                    <h3 className="text-md font-medium text-gray-900 mb-4">Team Management</h3>
                    <div className="bg-gray-50 rounded-lg p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium text-gray-900">Team Members</h4>
                          <p className="text-sm text-gray-600">Manage access for your security team</p>
                        </div>
                        <button 
                          onClick={() => showToast('info', 'Team member invitation feature coming soon!')}
                          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors duration-200"
                        >
                          Invite Members
                        </button>
                      </div>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-gray-200">
                    <button 
                      onClick={() => handleSave('organization')}
                      disabled={saveStatus === 'saving'}
                      className={getSaveButtonClass()}
                    >
                      <Save className="h-4 w-4 mr-2" />
                      {getSaveButtonText()}
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}