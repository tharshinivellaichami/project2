const express = require('express');
const {
  getDashboardOverview,
  getComplianceHeatMap,
  runComplianceAssessment
} = require('../controllers/dashboardController');

const { protect } = require('../middlewares/auth');

const router = express.Router();

router.use(protect); // All routes are protected

router.get('/overview', getDashboardOverview);
router.get('/compliance-heatmap', getComplianceHeatMap);
router.post('/run-assessment', runComplianceAssessment);

module.exports = router;