const express = require('express');
const {
  getAuditLogs,
  exportAuditLogs
} = require('../controllers/auditLogController');

const { protect } = require('../middlewares/auth');

const router = express.Router();

router.use(protect); // All routes are protected

router.get('/', getAuditLogs);
router.get('/export', exportAuditLogs);

module.exports = router;