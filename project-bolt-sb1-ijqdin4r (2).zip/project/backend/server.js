const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
require('dotenv').config();
const connectDB = require('./config/database');

const app = express();
const PORT = process.env.PORT || 5000;

// 🔗 Connect to MongoDB
connectDB();

// 🔒 Security middleware
app.use(helmet());
app.use(cors({
  origin: ['http://localhost:5173', 'https://localhost:5173'],
  credentials: true
}));

// 🔐 Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100
});
app.use(limiter);

// 📦 Body parsing middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// ✅ Health check
app.get('/api/health', (req, res) => {
  res.status(200).json({
    success: true,
    message: 'SecuroSync API is running',
    timestamp: new Date().toISOString()
  });
});

// 🔐 Mock Auth
app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  if (email === 'demo@securosync.com' && password === 'password123') {
    res.json({
      success: true,
      token: 'mock-jwt-token',
      user: {
        id: '1',
        email,
        name: 'Demo User',
        company: 'SecuroSync Demo'
      }
    });
  } else {
    res.status(401).json({ success: false, message: 'Invalid credentials' });
  }
});

// 📊 Mock Dashboard
app.get('/api/dashboard/overview', (req, res) => {
  res.json({
    success: true,
    data: {
      complianceScore: 85,
      totalControls: 64,
      implementedControls: 54,
      pendingActions: 10,
      recentActivity: [
        {
          id: '1',
          action: 'User login',
          timestamp: new Date().toISOString(),
          user: 'demo@securosync.com'
        }
      ]
    }
  });
});

// ❌ Error handling
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ success: false, message: 'Something went wrong!' });
});

// ❓ 404 fallback
app.use('*', (req, res) => {
  res.status(404).json({ success: false, message: 'Route not found' });
});

// 🚀 Start server
app.listen(PORT, () => {
  console.log(`🚀 SecuroSync API server running on port ${PORT}`);
  console.log(`📊 Health check: http://localhost:${PORT}/api/health`);
});
