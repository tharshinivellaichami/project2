const Joi = require('joi');

const validate = (schema) => {
  return (req, res, next) => {
    const { error } = schema.validate(req.body);
    
    if (error) {
      return res.status(400).json({
        success: false,
        message: 'Validation error',
        details: error.details.map(detail => detail.message)
      });
    }
    
    next();
  };
};

// Common validation schemas
const schemas = {
  register: Joi.object({
    name: Joi.string().min(2).max(50).required(),
    email: Joi.string().email().required(),
    password: Joi.string().min(6).required(),
    company: Joi.string().min(2).max(100).required(),
    complianceGoal: Joi.string().valid('SOC2', 'ISO27001', 'HIPAA', 'GDPR', 'Multiple').required()
  }),

  login: Joi.object({
    email: Joi.string().email().required(),
    password: Joi.string().required()
  }),

  integration: Joi.object({
    name: Joi.string().required(),
    type: Joi.string().required(),
    credentials: Joi.object().required(),
    settings: Joi.object().optional()
  })
};

module.exports = { validate, schemas };