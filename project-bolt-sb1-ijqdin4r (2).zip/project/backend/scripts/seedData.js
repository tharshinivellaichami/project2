const mongoose = require('mongoose');
const dotenv = require('dotenv');
const colors = require('colors');

// Load env vars
dotenv.config();

// Load models
const User = require('../models/User');
const ComplianceCheck = require('../models/ComplianceCheck');
const AuditLog = require('../models/AuditLog');

// Connect to DB
mongoose.connect(process.env.MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// Sample SOC 2 controls data
const soc2Controls = [
  // CC1 - Control Environment
  { controlId: 'CC1.1', framework: 'SOC2', category: 'Control Environment', name: 'Governance & Oversight', description: 'The entity demonstrates a commitment to integrity and ethical values', status: 'passed', score: 95 },
  { controlId: 'CC1.2', framework: 'SOC2', category: 'Control Environment', name: 'Management Philosophy', description: 'The board of directors demonstrates independence from management', status: 'passed', score: 88 },
  { controlId: 'CC1.3', framework: 'SOC2', category: 'Control Environment', name: 'Organizational Structure', description: 'Management establishes structures, reporting lines, and appropriate authorities', status: 'warning', score: 72 },
  { controlId: 'CC1.4', framework: 'SOC2', category: 'Control Environment', name: 'Competence & Training', description: 'The entity demonstrates a commitment to attract, develop, and retain competent individuals', status: 'critical', score: 45 },
  
  // CC2 - Communication & Information
  { controlId: 'CC2.1', framework: 'SOC2', category: 'Communication & Information', name: 'System Information', description: 'The entity obtains or generates and uses relevant, quality information', status: 'passed', score: 92 },
  { controlId: 'CC2.2', framework: 'SOC2', category: 'Communication & Information', name: 'Communication Objectives', description: 'The entity internally communicates information necessary to support functioning', status: 'warning', score: 68 },
  { controlId: 'CC2.3', framework: 'SOC2', category: 'Communication & Information', name: 'Communication Quality', description: 'The entity communicates with external parties regarding matters affecting functioning', status: 'passed', score: 85 },
  
  // CC3 - Risk Assessment
  { controlId: 'CC3.1', framework: 'SOC2', category: 'Risk Assessment', name: 'Risk Identification', description: 'The entity specifies objectives with sufficient clarity to enable identification of risks', status: 'critical', score: 35 },
  { controlId: 'CC3.2', framework: 'SOC2', category: 'Risk Assessment', name: 'Risk Analysis', description: 'The entity identifies risks to the achievement of its objectives', status: 'warning', score: 55 },
  { controlId: 'CC3.3', framework: 'SOC2', category: 'Risk Assessment', name: 'Risk Response', description: 'The entity considers the potential for fraud in assessing risks', status: 'warning', score: 62 },
  
  // CC4 - Monitoring Activities
  { controlId: 'CC4.1', framework: 'SOC2', category: 'Monitoring Activities', name: 'Monitoring Controls', description: 'The entity selects, develops, and performs ongoing and/or separate evaluations', status: 'passed', score: 90 },
  { controlId: 'CC4.2', framework: 'SOC2', category: 'Monitoring Activities', name: 'Evaluation & Communication', description: 'The entity evaluates and communicates internal control deficiencies', status: 'passed', score: 87 },
  
  // CC5 - Control Activities
  { controlId: 'CC5.1', framework: 'SOC2', category: 'Control Activities', name: 'Logical Access Controls', description: 'The entity implements logical access security software and configures access settings', status: 'warning', score: 75 },
  { controlId: 'CC5.2', framework: 'SOC2', category: 'Control Activities', name: 'System Access Controls', description: 'The entity restricts the use of system utilities and privileged-access programs', status: 'passed', score: 93 },
  { controlId: 'CC5.3', framework: 'SOC2', category: 'Control Activities', name: 'Data Protection', description: 'The entity protects against unauthorized access to data', status: 'critical', score: 40 }
];

// Seed data
const seedData = async () => {
  try {
    // Clear existing data
    await User.deleteMany();
    await ComplianceCheck.deleteMany();
    await AuditLog.deleteMany();

    console.log('Data Destroyed...'.red.inverse);

    // Create demo user
    const demoUser = await User.create({
      name: 'Demo User',
      email: 'demo@securosync.com',
      password: 'password123',
      company: 'SecuroSync Demo',
      complianceGoal: 'SOC2',
      role: 'admin'
    });

    console.log('Demo user created...'.green.inverse);

    // Create compliance checks for demo user
    const complianceChecks = soc2Controls.map(control => ({
      ...control,
      user: demoUser._id,
      lastAssessed: new Date(),
      issues: control.status === 'critical' ? [
        {
          severity: 'critical',
          description: 'Critical compliance gap identified',
          remediation: 'Immediate action required',
          status: 'open'
        }
      ] : control.status === 'warning' ? [
        {
          severity: 'medium',
          description: 'Compliance improvement needed',
          remediation: 'Schedule remediation within 30 days',
          status: 'open'
        }
      ] : []
    }));

    await ComplianceCheck.insertMany(complianceChecks);

    console.log('Compliance checks created...'.green.inverse);

    // Create sample audit logs
    const auditLogs = [
      {
        user: demoUser._id,
        action: 'Login Successful',
        resource: 'Authentication System',
        details: 'User successfully authenticated with MFA',
        ipAddress: '192.168.1.100',
        userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        severity: 'success',
        category: 'authentication'
      },
      {
        user: demoUser._id,
        action: 'Generated Compliance Report',
        resource: 'SOC 2 Assessment',
        details: 'Generated quarterly SOC 2 compliance report',
        ipAddress: '192.168.1.100',
        userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        severity: 'info',
        category: 'compliance'
      },
      {
        user: demoUser._id,
        action: 'Critical Issue Detected',
        resource: 'AWS S3 Bucket',
        details: 'Public read access detected on sensitive data bucket',
        ipAddress: 'N/A',
        userAgent: 'SecuroSync Automated Scanner',
        severity: 'critical',
        category: 'compliance'
      }
    ];

    await AuditLog.insertMany(auditLogs);

    console.log('Audit logs created...'.green.inverse);

    console.log('✅ Seed data created successfully!'.green.bold);
    console.log('📧 Demo login: demo@securosync.com'.cyan);
    console.log('🔑 Demo password: password123'.cyan);

    process.exit();
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
};

// Run seeder
if (process.argv[2] === '-d') {
  // Destroy data
  (async () => {
    try {
      await User.deleteMany();
      await ComplianceCheck.deleteMany();
      await AuditLog.deleteMany();
      console.log('Data Destroyed...'.red.inverse);
      process.exit();
    } catch (err) {
      console.error(err);
      process.exit(1);
    }
  })();
} else {
  seedData();
}