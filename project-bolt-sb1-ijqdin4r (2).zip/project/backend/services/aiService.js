const OpenAI = require('openai');
const { OPENAI_API_KEY } = require('../config/env');
const logger = require('../utils/logger');

class AIService {
  constructor() {
    this.openai = new OpenAI({
      apiKey: OPENAI_API_KEY
    });
  }

  async analyzeCompliance(control, evidence) {
    try {
      const prompt = this.buildCompliancePrompt(control, evidence);
      
      const response = await this.openai.chat.completions.create({
        model: 'gpt-4',
        messages: [
          {
            role: 'system',
            content: 'You are a cybersecurity compliance expert specializing in SOC 2, ISO 27001, and HIPAA frameworks. Analyze the provided evidence and determine compliance status.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        temperature: 0.1,
        max_tokens: 1000
      });

      const analysis = JSON.parse(response.choices[0].message.content);
      
      return {
        status: analysis.status,
        score: analysis.score,
        issues: analysis.issues || [],
        recommendations: analysis.recommendations || [],
        reasoning: analysis.reasoning
      };
    } catch (error) {
      logger.error('AI analysis error:', error);
      return {
        status: 'warning',
        score: 50,
        issues: [{ severity: 'medium', description: 'Unable to perform AI analysis' }],
        recommendations: ['Manual review required'],
        reasoning: 'AI analysis failed'
      };
    }
  }

  async generateRemediation(control, issues) {
    try {
      const prompt = `
        Control: ${control.name} (${control.controlId})
        Framework: ${control.framework}
        Issues: ${JSON.stringify(issues)}
        
        Generate step-by-step remediation instructions for these compliance issues.
        Include specific commands, configurations, and best practices.
        Format as JSON with steps array.
      `;

      const response = await this.openai.chat.completions.create({
        model: 'gpt-4',
        messages: [
          {
            role: 'system',
            content: 'You are a cybersecurity expert providing detailed remediation steps for compliance issues.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        temperature: 0.1,
        max_tokens: 1500
      });

      return JSON.parse(response.choices[0].message.content);
    } catch (error) {
      logger.error('Remediation generation error:', error);
      return {
        steps: ['Manual remediation required - AI service unavailable']
      };
    }
  }

  async chatWithSecuroBot(message, context = {}) {
    try {
      const systemPrompt = `
        You are SecuroBot, an AI security compliance assistant for SecuroSync.
        You help users with:
        - SOC 2, ISO 27001, HIPAA compliance questions
        - Infrastructure security best practices
        - Step-by-step implementation guides
        - Policy template generation
        
        Be helpful, accurate, and provide actionable advice.
        If you don't know something, say so and suggest alternatives.
      `;

      const response = await this.openai.chat.completions.create({
        model: 'gpt-4',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: message }
        ],
        temperature: 0.3,
        max_tokens: 1000
      });

      return {
        message: response.choices[0].message.content,
        timestamp: new Date()
      };
    } catch (error) {
      logger.error('SecuroBot chat error:', error);
      return {
        message: 'I apologize, but I\'m experiencing technical difficulties. Please try again later.',
        timestamp: new Date()
      };
    }
  }

  buildCompliancePrompt(control, evidence) {
    return `
      Analyze this compliance control:
      
      Control ID: ${control.controlId}
      Name: ${control.name}
      Framework: ${control.framework}
      Category: ${control.category}
      Description: ${control.description}
      
      Evidence collected:
      ${JSON.stringify(evidence, null, 2)}
      
      Determine:
      1. Compliance status (passed/warning/critical)
      2. Score (0-100)
      3. Issues found (if any)
      4. Recommendations for improvement
      
      Respond in JSON format:
      {
        "status": "passed|warning|critical",
        "score": 0-100,
        "issues": [{"severity": "low|medium|high|critical", "description": "..."}],
        "recommendations": ["..."],
        "reasoning": "..."
      }
    `;
  }
}

module.exports = new AIService();