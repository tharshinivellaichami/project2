const ComplianceControl = require('../models/ComplianceControl');
const Integration = require('../models/Integration');
const aiService = require('./aiService');
const logger = require('../utils/logger');

class ComplianceService {
  async getComplianceOverview(userId) {
    try {
      const controls = await ComplianceControl.find({ user: userId });
      
      const overview = {
        totalControls: controls.length,
        passed: controls.filter(c => c.status === 'passed').length,
        warnings: controls.filter(c => c.status === 'warning').length,
        critical: controls.filter(c => c.status === 'critical').length,
        overallScore: this.calculateOverallScore(controls),
        frameworks: this.getFrameworkBreakdown(controls),
        recentAssessments: controls
          .sort((a, b) => b.lastAssessed - a.lastAssessed)
          .slice(0, 5)
      };
      
      return overview;
    } catch (error) {
      logger.error('Error getting compliance overview:', error);
      throw error;
    }
  }

  async runAssessment(userId, framework, controlIds = null) {
    try {
      const integrations = await Integration.find({ 
        user: userId, 
        status: 'connected' 
      });
      
      if (integrations.length === 0) {
        throw new Error('No active integrations found');
      }
      
      const filters = { user: userId };
      if (framework) filters.framework = framework;
      if (controlIds) filters.controlId = { $in: controlIds };
      
      const controls = await ComplianceControl.find(filters);
      const assessmentResults = [];
      
      for (const control of controls) {
        const result = await this.assessControl(control, integrations);
        assessmentResults.push(result);
      }
      
      return {
        assessmentId: this.generateAssessmentId(),
        timestamp: new Date(),
        framework,
        controlsAssessed: assessmentResults.length,
        results: assessmentResults,
        summary: this.generateAssessmentSummary(assessmentResults)
      };
    } catch (error) {
      logger.error('Error running assessment:', error);
      throw error;
    }
  }

  async assessControl(control, integrations) {
    try {
      // Collect evidence from integrations
      const evidence = await this.collectEvidence(control, integrations);
      
      // Use AI to analyze compliance
      const aiAnalysis = await aiService.analyzeCompliance(control, evidence);
      
      // Update control with new assessment
      control.status = aiAnalysis.status;
      control.score = aiAnalysis.score;
      control.lastAssessed = new Date();
      control.evidence = evidence;
      control.issues = aiAnalysis.issues;
      
      await control.save();
      
      return {
        controlId: control.controlId,
        name: control.name,
        status: control.status,
        score: control.score,
        issues: control.issues,
        recommendations: aiAnalysis.recommendations
      };
    } catch (error) {
      logger.error(`Error assessing control ${control.controlId}:`, error);
      return {
        controlId: control.controlId,
        name: control.name,
        status: 'error',
        error: error.message
      };
    }
  }

  async collectEvidence(control, integrations) {
    const evidence = [];
    
    for (const integration of integrations) {
      try {
        const integrationService = require(`./integrations/${integration.type}Service`);
        const data = await integrationService.collectEvidenceForControl(control, integration);
        
        if (data) {
          evidence.push({
            type: 'configuration',
            source: integration.type,
            data,
            timestamp: new Date()
          });
        }
      } catch (error) {
        logger.error(`Error collecting evidence from ${integration.type}:`, error);
      }
    }
    
    return evidence;
  }

  calculateOverallScore(controls) {
    if (controls.length === 0) return 0;
    
    const totalScore = controls.reduce((sum, control) => sum + control.score, 0);
    return Math.round(totalScore / controls.length);
  }

  getFrameworkBreakdown(controls) {
    const frameworks = {};
    
    controls.forEach(control => {
      if (!frameworks[control.framework]) {
        frameworks[control.framework] = {
          total: 0,
          passed: 0,
          warnings: 0,
          critical: 0
        };
      }
      
      frameworks[control.framework].total++;
      frameworks[control.framework][control.status]++;
    });
    
    return frameworks;
  }

  generateAssessmentId() {
    return `assessment_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  generateAssessmentSummary(results) {
    const summary = {
      total: results.length,
      passed: results.filter(r => r.status === 'passed').length,
      warnings: results.filter(r => r.status === 'warning').length,
      critical: results.filter(r => r.status === 'critical').length,
      errors: results.filter(r => r.status === 'error').length
    };
    
    summary.successRate = Math.round((summary.passed / summary.total) * 100);
    
    return summary;
  }
}

module.exports = new ComplianceService();