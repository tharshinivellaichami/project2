# SecuroSync Backend API

A modular, scalable backend for the SecuroSync AI-powered CISO platform.

## 🏗️ Architecture

```
backend/
├── /api            # RESTful endpoint definitions (routes)
├── /controllers    # Logic for handling requests
├── /services       # Core business logic (compliance AI, audit tools, etc.)
├── /models         # Database schemas (MongoDB)
├── /utils          # Helper functions (validators, logger, etc.)
├── /middlewares    # Auth, logging, rate limiting
├── /config         # Environment variables, DB configs, API keys
├── app.js          # Express app initialization
└── server.js       # Server entry point
```

## 🚀 Quick Start

1. **Install Dependencies**
   ```bash
   npm install
   ```

2. **Environment Setup**
   ```bash
   cp .env.example .env
   # Edit .env with your configuration
   ```

3. **Start Development Server**
   ```bash
   npm run dev
   ```

4. **Run Tests**
   ```bash
   npm test
   ```

## 📡 API Endpoints

### Authentication
- `POST /api/auth/register` - User registration
- `POST /api/auth/login` - User login
- `GET /api/auth/me` - Get current user

### Compliance
- `GET /api/compliance/overview` - Compliance dashboard data
- `GET /api/compliance/controls` - List compliance controls
- `POST /api/compliance/assess` - Run compliance assessment

### Integrations
- `GET /api/integrations` - List user integrations
- `POST /api/integrations` - Create new integration
- `PUT /api/integrations/:id` - Update integration
- `DELETE /api/integrations/:id` - Remove integration

### AI Assistant
- `POST /api/ai/chat` - Chat with SecuroBot
- `POST /api/ai/remediation` - Generate remediation steps

### Reports
- `GET /api/reports` - List generated reports
- `POST /api/reports/generate` - Generate new report
- `GET /api/reports/:id/download` - Download report

## 🔧 Key Features

### Modular Design
- **Easy to extend**: Add new integrations by creating services in `/services/integrations/`
- **Clean separation**: Routes, business logic, and data models are separated
- **Reusable components**: Utilities and middleware can be shared across features

### Security
- JWT authentication
- Rate limiting
- Input validation with Joi
- Helmet.js security headers
- CORS configuration

### AI Integration
- OpenAI GPT-4 for compliance analysis
- Automated remediation suggestions
- SecuroBot chat assistant

### Monitoring & Logging
- Winston logger with multiple transports
- Error tracking and debugging
- Performance monitoring ready

## 🔌 Adding New Integrations

1. Create service file: `/services/integrations/newServiceName.js`
2. Implement required methods:
   ```javascript
   class NewIntegrationService {
     async connect(credentials) { /* ... */ }
     async collectEvidenceForControl(control, integration) { /* ... */ }
     async testConnection(integration) { /* ... */ }
   }
   ```
3. Add to integration types in models and validation
4. Create API endpoints in `/api/integrations.js`

## 🧪 Testing

```bash
# Run all tests
npm test

# Run with coverage
npm run test:coverage

# Run specific test file
npm test -- --testPathPattern=auth
```

## 📦 Deployment

### Environment Variables
Ensure all required environment variables are set in production:
- `NODE_ENV=production`
- `MONGODB_URI`
- `JWT_SECRET`
- `OPENAI_API_KEY`
- Integration credentials (AWS, GitHub, etc.)

### Docker Deployment
```bash
# Build image
docker build -t securosync-backend .

# Run container
docker run -p 5000:5000 --env-file .env securosync-backend
```

## 🔍 Monitoring

- Health check endpoint: `GET /health`
- Logs stored in `/logs/` directory
- Error tracking with Winston
- Performance metrics ready for integration

## 🤝 Contributing

1. Follow the existing folder structure
2. Add tests for new features
3. Use ESLint for code formatting
4. Update documentation for new endpoints