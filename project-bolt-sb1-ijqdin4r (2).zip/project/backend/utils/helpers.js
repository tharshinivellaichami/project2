const crypto = require('crypto');

const helpers = {
  // Generate unique IDs
  generateId: (prefix = '') => {
    const timestamp = Date.now().toString(36);
    const random = crypto.randomBytes(4).toString('hex');
    return `${prefix}${timestamp}_${random}`;
  },

  // Sanitize data for logging
  sanitizeForLog: (data) => {
    const sanitized = { ...data };
    const sensitiveFields = ['password', 'token', 'apiKey', 'secret', 'credentials'];
    
    sensitiveFields.forEach(field => {
      if (sanitized[field]) {
        sanitized[field] = '[REDACTED]';
      }
    });
    
    return sanitized;
  },

  // Calculate compliance score
  calculateComplianceScore: (controls) => {
    if (!controls || controls.length === 0) return 0;
    
    const totalScore = controls.reduce((sum, control) => sum + (control.score || 0), 0);
    return Math.round(totalScore / controls.length);
  },

  // Format date for reports
  formatDate: (date, format = 'YYYY-MM-DD') => {
    const d = new Date(date);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    
    switch (format) {
      case 'YYYY-MM-DD':
        return `${year}-${month}-${day}`;
      case 'MM/DD/YYYY':
        return `${month}/${day}/${year}`;
      case 'DD/MM/YYYY':
        return `${day}/${month}/${year}`;
      default:
        return d.toISOString();
    }
  },

  // Paginate results
  paginate: (query, page = 1, limit = 10) => {
    const skip = (page - 1) * limit;
    return query.skip(skip).limit(limit);
  },

  // Generate API response
  apiResponse: (success, data = null, message = '', meta = {}) => {
    const response = {
      success,
      timestamp: new Date().toISOString()
    };
    
    if (data !== null) response.data = data;
    if (message) response.message = message;
    if (Object.keys(meta).length > 0) response.meta = meta;
    
    return response;
  }
};

module.exports = helpers;