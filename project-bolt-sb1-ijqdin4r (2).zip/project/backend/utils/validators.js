const Joi = require('joi');

const validators = {
  // User validation
  userRegistration: Joi.object({
    name: Joi.string().min(2).max(50).required(),
    email: Joi.string().email().required(),
    password: Joi.string().min(6).required(),
    company: Joi.string().min(2).max(100).required(),
    complianceGoal: Joi.string().valid('SOC2', 'ISO27001', 'HIPAA', 'GDPR', 'Multiple').required()
  }),

  // Integration validation
  integration: Joi.object({
    name: Joi.string().required(),
    type: Joi.string().valid('aws', 'github', 'gitlab', 'azure', 'gcp', 'okta', 'kubernetes').required(),
    credentials: Joi.object().required(),
    settings: Joi.object().optional()
  }),

  // Assessment validation
  assessment: Joi.object({
    framework: Joi.string().valid('SOC2', 'ISO27001', 'HIPAA', 'GDPR').optional(),
    controlIds: Joi.array().items(Joi.string()).optional()
  }),

  // Report generation validation
  reportGeneration: Joi.object({
    type: Joi.string().valid('compliance', 'security', 'audit').required(),
    framework: Joi.string().valid('SOC2', 'ISO27001', 'HIPAA', 'GDPR').required(),
    includeEvidence: Joi.boolean().default(true),
    format: Joi.string().valid('pdf', 'html', 'json').default('pdf')
  })
};

module.exports = validators;