const AuditLog = require('../models/AuditLog');
const asyncHandler = require('../utils/asyncHandler');

// @desc    Get audit logs
// @route   GET /api/audit-logs
// @access  Private
const getAuditLogs = asyncHandler(async (req, res, next) => {
  const {
    page = 1,
    limit = 20,
    category,
    severity,
    search,
    startDate,
    endDate
  } = req.query;

  // Build query
  const query = { user: req.user.id };

  if (category && category !== 'all') {
    query.category = category;
  }

  if (severity && severity !== 'all') {
    query.severity = severity;
  }

  if (search) {
    query.$or = [
      { action: { $regex: search, $options: 'i' } },
      { details: { $regex: search, $options: 'i' } },
      { resource: { $regex: search, $options: 'i' } }
    ];
  }

  if (startDate || endDate) {
    query.createdAt = {};
    if (startDate) query.createdAt.$gte = new Date(startDate);
    if (endDate) query.createdAt.$lte = new Date(endDate);
  }

  // Execute query with pagination
  const logs = await AuditLog.find(query)
    .sort({ createdAt: -1 })
    .limit(limit * 1)
    .skip((page - 1) * limit)
    .populate('user', 'name email');

  // Get total count for pagination
  const total = await AuditLog.countDocuments(query);

  // Get statistics
  const stats = await AuditLog.aggregate([
    { $match: { user: req.user.id } },
    {
      $group: {
        _id: null,
        total: { $sum: 1 },
        critical: {
          $sum: { $cond: [{ $eq: ['$severity', 'critical'] }, 1, 0] }
        },
        warning: {
          $sum: { $cond: [{ $eq: ['$severity', 'warning'] }, 1, 0] }
        },
        info: {
          $sum: { $cond: [{ $eq: ['$severity', 'info'] }, 1, 0] }
        },
        success: {
          $sum: { $cond: [{ $eq: ['$severity', 'success'] }, 1, 0] }
        }
      }
    }
  ]);

  // Get category breakdown
  const categories = await AuditLog.aggregate([
    { $match: { user: req.user.id } },
    {
      $group: {
        _id: '$category',
        count: { $sum: 1 }
      }
    }
  ]);

  res.status(200).json({
    success: true,
    data: {
      logs: logs.map(log => ({
        id: log._id,
        timestamp: log.createdAt,
        user: log.user ? log.user.email : 'System',
        action: log.action,
        resource: log.resource,
        details: log.details,
        ipAddress: log.ipAddress,
        userAgent: log.userAgent,
        severity: log.severity,
        category: log.category
      })),
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      },
      stats: stats[0] || { total: 0, critical: 0, warning: 0, info: 0, success: 0 },
      categories: categories.reduce((acc, cat) => {
        acc[cat._id] = cat.count;
        return acc;
      }, {})
    }
  });
});

// @desc    Export audit logs
// @route   GET /api/audit-logs/export
// @access  Private
const exportAuditLogs = asyncHandler(async (req, res, next) => {
  const { format = 'csv', ...filters } = req.query;

  // Build query (similar to getAuditLogs)
  const query = { user: req.user.id };
  
  if (filters.category && filters.category !== 'all') {
    query.category = filters.category;
  }

  if (filters.severity && filters.severity !== 'all') {
    query.severity = filters.severity;
  }

  const logs = await AuditLog.find(query)
    .sort({ createdAt: -1 })
    .populate('user', 'name email')
    .limit(10000); // Limit export to 10k records

  // Log the export action
  await AuditLog.create({
    user: req.user.id,
    action: 'Audit Logs Exported',
    resource: 'Audit System',
    details: `Exported ${logs.length} audit logs in ${format} format`,
    ipAddress: req.ip,
    userAgent: req.get('User-Agent'),
    severity: 'info',
    category: 'system'
  });

  if (format === 'csv') {
    // Generate CSV
    const csvHeader = 'Timestamp,User,Action,Resource,Details,IP Address,Severity,Category\n';
    const csvData = logs.map(log => 
      `"${log.createdAt}","${log.user ? log.user.email : 'System'}","${log.action}","${log.resource}","${log.details}","${log.ipAddress}","${log.severity}","${log.category}"`
    ).join('\n');

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename=audit-logs.csv');
    res.send(csvHeader + csvData);
  } else {
    // Return JSON
    res.status(200).json({
      success: true,
      data: logs,
      exportedAt: new Date(),
      count: logs.length
    });
  }
});

module.exports = {
  getAuditLogs,
  exportAuditLogs
};