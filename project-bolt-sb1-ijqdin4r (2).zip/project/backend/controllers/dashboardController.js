const User = require('../models/User');
const ComplianceCheck = require('../models/ComplianceCheck');
const AuditLog = require('../models/AuditLog');
const asyncHandler = require('../utils/asyncHandler');

// @desc    Get dashboard overview data
// @route   GET /api/dashboard/overview
// @access  Private
const getDashboardOverview = asyncHandler(async (req, res, next) => {
  const userId = req.user.id;

  // Get compliance checks for the user
  const complianceChecks = await ComplianceCheck.find({ user: userId });
  
  // Calculate compliance score
  const totalChecks = complianceChecks.length;
  const passedChecks = complianceChecks.filter(check => check.status === 'passed').length;
  const warningChecks = complianceChecks.filter(check => check.status === 'warning').length;
  const criticalChecks = complianceChecks.filter(check => check.status === 'critical').length;
  
  const complianceScore = totalChecks > 0 ? Math.round((passedChecks / totalChecks) * 100) : 0;

  // Get recent activity logs
  const recentActivity = await AuditLog.find({ user: userId })
    .sort({ createdAt: -1 })
    .limit(10)
    .populate('user', 'name email');

  // Get upcoming tasks (mock data for now)
  const upcomingTasks = [
    {
      task: 'Quarterly security review',
      due: '3 days',
      priority: 'high'
    },
    {
      task: 'Update incident response plan',
      due: '1 week',
      priority: 'medium'
    },
    {
      task: 'AWS access review',
      due: '2 weeks',
      priority: 'low'
    }
  ];

  // Get controls overview by category
  const controlsByCategory = await ComplianceCheck.aggregate([
    { $match: { user: userId } },
    {
      $group: {
        _id: '$category',
        total: { $sum: 1 },
        passed: {
          $sum: { $cond: [{ $eq: ['$status', 'passed'] }, 1, 0] }
        },
        warning: {
          $sum: { $cond: [{ $eq: ['$status', 'warning'] }, 1, 0] }
        },
        critical: {
          $sum: { $cond: [{ $eq: ['$status', 'critical'] }, 1, 0] }
        },
        avgScore: { $avg: '$score' }
      }
    }
  ]);

  // Log dashboard access
  await AuditLog.create({
    user: userId,
    action: 'Dashboard Accessed',
    resource: 'Dashboard',
    details: 'User accessed main dashboard',
    ipAddress: req.ip,
    userAgent: req.get('User-Agent'),
    severity: 'info',
    category: 'system'
  });

  res.status(200).json({
    success: true,
    data: {
      complianceScore,
      stats: {
        totalControls: totalChecks,
        passedControls: passedChecks,
        warningIssues: warningChecks,
        criticalIssues: criticalChecks
      },
      recentActivity: recentActivity.map(log => ({
        id: log._id,
        type: log.category,
        message: log.details,
        time: log.createdAt,
        severity: log.severity,
        user: log.user ? log.user.name : 'System'
      })),
      upcomingTasks,
      controlsByCategory: controlsByCategory.map(cat => ({
        name: cat._id,
        status: cat.critical > 0 ? 'critical' : cat.warning > 0 ? 'warning' : 'passed',
        score: Math.round(cat.avgScore || 0),
        issues: cat.warning + cat.critical,
        trend: '+5%' // Mock trend data
      }))
    }
  });
});

// @desc    Get compliance heat map data
// @route   GET /api/dashboard/compliance-heatmap
// @access  Private
const getComplianceHeatMap = asyncHandler(async (req, res, next) => {
  const userId = req.user.id;
  const { framework = 'SOC2' } = req.query;

  const complianceChecks = await ComplianceCheck.find({ 
    user: userId,
    framework: framework.toUpperCase()
  }).sort({ controlId: 1 });

  // Group by category
  const categories = {};
  complianceChecks.forEach(check => {
    if (!categories[check.category]) {
      categories[check.category] = [];
    }
    categories[check.category].push({
      id: check.controlId,
      name: check.name,
      status: check.status,
      score: check.score,
      lastCheck: check.lastAssessed,
      issues: check.issues.filter(issue => issue.status === 'open')
    });
  });

  res.status(200).json({
    success: true,
    data: {
      framework,
      categories,
      summary: {
        total: complianceChecks.length,
        passed: complianceChecks.filter(c => c.status === 'passed').length,
        warning: complianceChecks.filter(c => c.status === 'warning').length,
        critical: complianceChecks.filter(c => c.status === 'critical').length
      }
    }
  });
});

// @desc    Run compliance assessment
// @route   POST /api/dashboard/run-assessment
// @access  Private
const runComplianceAssessment = asyncHandler(async (req, res, next) => {
  const userId = req.user.id;
  const { framework = 'SOC2' } = req.body;

  // Log assessment start
  await AuditLog.create({
    user: userId,
    action: 'Compliance Assessment Started',
    resource: 'Compliance Engine',
    details: `Started ${framework} compliance assessment`,
    ipAddress: req.ip,
    userAgent: req.get('User-Agent'),
    severity: 'info',
    category: 'compliance'
  });

  // Simulate assessment process (in real implementation, this would trigger actual checks)
  const assessmentId = `assessment_${Date.now()}`;
  
  // Update some compliance checks with new timestamps
  await ComplianceCheck.updateMany(
    { user: userId, framework: framework.toUpperCase() },
    { lastAssessed: new Date() }
  );

  res.status(200).json({
    success: true,
    data: {
      assessmentId,
      status: 'started',
      message: 'Compliance assessment initiated successfully',
      estimatedCompletion: '2-3 minutes'
    }
  });
});

module.exports = {
  getDashboardOverview,
  getComplianceHeatMap,
  runComplianceAssessment
};