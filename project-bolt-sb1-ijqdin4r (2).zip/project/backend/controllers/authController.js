const User = require('../models/User');
const AuditLog = require('../models/AuditLog');
const asyncHandler = require('../utils/asyncHandler');
const ErrorResponse = require('../utils/errorResponse');

// @desc    Register user
// @route   POST /api/auth/register
// @access  Public
const register = asyncHandler(async (req, res, next) => {
  const { name, email, password, company, complianceGoal } = req.body;

  // Check if user exists
  const existingUser = await User.findOne({ email });
  if (existingUser) {
    return next(new ErrorResponse('User already exists', 400));
  }

  // Create user
  const user = await User.create({
    name,
    email,
    password,
    company,
    complianceGoal
  });

  // Log the registration
  await AuditLog.create({
    user: user._id,
    action: 'User Registration',
    resource: 'Authentication System',
    details: `New user registered: ${email}`,
    ipAddress: req.ip,
    userAgent: req.get('User-Agent'),
    severity: 'info',
    category: 'authentication'
  });

  sendTokenResponse(user, 201, res);
});

// @desc    Login user
// @route   POST /api/auth/login
// @access  Public
const login = asyncHandler(async (req, res, next) => {
  const { email, password } = req.body;

  // Validate email & password
  if (!email || !password) {
    return next(new ErrorResponse('Please provide an email and password', 400));
  }

  // Check for user
  const user = await User.findOne({ email }).select('+password');

  if (!user) {
    // Log failed login attempt
    await AuditLog.create({
      user: null,
      action: 'Failed Login Attempt',
      resource: 'Authentication System',
      details: `Login attempt with non-existent email: ${email}`,
      ipAddress: req.ip,
      userAgent: req.get('User-Agent'),
      severity: 'warning',
      category: 'authentication',
      metadata: { email }
    });
    return next(new ErrorResponse('Invalid credentials', 401));
  }

  // Check if password matches
  const isMatch = await user.matchPassword(password);

  if (!isMatch) {
    // Log failed login attempt
    await AuditLog.create({
      user: user._id,
      action: 'Failed Login Attempt',
      resource: 'Authentication System',
      details: `Invalid password provided for user: ${email}`,
      ipAddress: req.ip,
      userAgent: req.get('User-Agent'),
      severity: 'warning',
      category: 'authentication'
    });
    return next(new ErrorResponse('Invalid credentials', 401));
  }

  // Update last login
  user.lastLogin = new Date();
  await user.save();

  // Log successful login
  await AuditLog.create({
    user: user._id,
    action: 'Login Successful',
    resource: 'Authentication System',
    details: `User successfully authenticated: ${email}`,
    ipAddress: req.ip,
    userAgent: req.get('User-Agent'),
    severity: 'success',
    category: 'authentication'
  });

  sendTokenResponse(user, 200, res);
});

// @desc    Log user out / clear cookie
// @route   GET /api/auth/logout
// @access  Private
const logout = asyncHandler(async (req, res, next) => {
  // Log logout
  await AuditLog.create({
    user: req.user.id,
    action: 'User Logout',
    resource: 'Authentication System',
    details: `User logged out: ${req.user.email}`,
    ipAddress: req.ip,
    userAgent: req.get('User-Agent'),
    severity: 'info',
    category: 'authentication'
  });

  res.status(200).json({
    success: true,
    message: 'Logged out successfully'
  });
});

// @desc    Get current logged in user
// @route   GET /api/auth/me
// @access  Private
const getMe = asyncHandler(async (req, res, next) => {
  const user = await User.findById(req.user.id);

  res.status(200).json({
    success: true,
    data: user
  });
});

// @desc    Update user details
// @route   PUT /api/auth/updatedetails
// @access  Private
const updateDetails = asyncHandler(async (req, res, next) => {
  const fieldsToUpdate = {
    name: req.body.name,
    email: req.body.email,
    company: req.body.company
  };

  const user = await User.findByIdAndUpdate(req.user.id, fieldsToUpdate, {
    new: true,
    runValidators: true
  });

  // Log profile update
  await AuditLog.create({
    user: req.user.id,
    action: 'Profile Updated',
    resource: 'User Profile',
    details: `User profile updated: ${user.email}`,
    ipAddress: req.ip,
    userAgent: req.get('User-Agent'),
    severity: 'info',
    category: 'system'
  });

  res.status(200).json({
    success: true,
    data: user
  });
});

// @desc    Update password
// @route   PUT /api/auth/updatepassword
// @access  Private
const updatePassword = asyncHandler(async (req, res, next) => {
  const user = await User.findById(req.user.id).select('+password');

  // Check current password
  if (!(await user.matchPassword(req.body.currentPassword))) {
    return next(new ErrorResponse('Password is incorrect', 401));
  }

  user.password = req.body.newPassword;
  await user.save();

  // Log password change
  await AuditLog.create({
    user: req.user.id,
    action: 'Password Changed',
    resource: 'User Security',
    details: `Password updated for user: ${user.email}`,
    ipAddress: req.ip,
    userAgent: req.get('User-Agent'),
    severity: 'info',
    category: 'authentication'
  });

  sendTokenResponse(user, 200, res);
});

// Get token from model, create cookie and send response
const sendTokenResponse = (user, statusCode, res) => {
  // Create token
  const token = user.getSignedJwtToken();

  const options = {
    expires: new Date(
      Date.now() + process.env.JWT_COOKIE_EXPIRE * 24 * 60 * 60 * 1000
    ),
    httpOnly: true
  };

  if (process.env.NODE_ENV === 'production') {
    options.secure = true;
  }

  res.status(statusCode).json({
    success: true,
    token,
    data: {
      id: user._id,
      name: user.name,
      email: user.email,
      company: user.company,
      role: user.role,
      complianceGoal: user.complianceGoal,
      lastLogin: user.lastLogin
    }
  });
};

module.exports = {
  register,
  login,
  logout,
  getMe,
  updateDetails,
  updatePassword
};