const express = require('express');
const ComplianceControl = require('../models/ComplianceControl');
const complianceService = require('../services/complianceService');
const logger = require('../utils/logger');

const router = express.Router();

// @desc    Get compliance overview
// @route   GET /api/compliance/overview
// @access  Private
router.get('/overview', async (req, res) => {
  try {
    const userId = req.user.id;
    const overview = await complianceService.getComplianceOverview(userId);
    
    res.json({
      success: true,
      data: overview
    });
  } catch (error) {
    logger.error('Compliance overview error:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching compliance overview'
    });
  }
});

// @desc    Get compliance controls
// @route   GET /api/compliance/controls
// @access  Private
router.get('/controls', async (req, res) => {
  try {
    const userId = req.user.id;
    const { framework, status, category } = req.query;
    
    const filters = { user: userId };
    if (framework) filters.framework = framework;
    if (status) filters.status = status;
    if (category) filters.category = category;
    
    const controls = await ComplianceControl.find(filters)
      .sort({ lastAssessed: -1 });
    
    res.json({
      success: true,
      count: controls.length,
      data: controls
    });
  } catch (error) {
    logger.error('Get controls error:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching compliance controls'
    });
  }
});

// @desc    Get specific control details
// @route   GET /api/compliance/controls/:id
// @access  Private
router.get('/controls/:id', async (req, res) => {
  try {
    const control = await ComplianceControl.findOne({
      _id: req.params.id,
      user: req.user.id
    });
    
    if (!control) {
      return res.status(404).json({
        success: false,
        message: 'Control not found'
      });
    }
    
    res.json({
      success: true,
      data: control
    });
  } catch (error) {
    logger.error('Get control error:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching control details'
    });
  }
});

// @desc    Run compliance assessment
// @route   POST /api/compliance/assess
// @access  Private
router.post('/assess', async (req, res) => {
  try {
    const userId = req.user.id;
    const { framework, controlIds } = req.body;
    
    const assessment = await complianceService.runAssessment(userId, framework, controlIds);
    
    res.json({
      success: true,
      data: assessment
    });
  } catch (error) {
    logger.error('Compliance assessment error:', error);
    res.status(500).json({
      success: false,
      message: 'Error running compliance assessment'
    });
  }
});

module.exports = router;