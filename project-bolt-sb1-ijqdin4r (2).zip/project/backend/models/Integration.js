const mongoose = require('mongoose');

const integrationSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.ObjectId,
    ref: 'User',
    required: true
  },
  name: {
    type: String,
    required: [true, 'Please add an integration name'],
    trim: true
  },
  type: {
    type: String,
    required: [true, 'Please specify integration type'],
    enum: ['aws', 'github', 'gitlab', 'azure', 'gcp', 'okta', 'kubernetes']
  },
  status: {
    type: String,
    enum: ['connected', 'disconnected', 'error', 'pending'],
    default: 'pending'
  },
  credentials: {
    type: mongoose.Schema.Types.Mixed,
    required: true
  },
  settings: {
    type: mongoose.Schema.Types.Mixed,
    default: {}
  },
  lastSync: {
    type: Date
  },
  syncStatus: {
    type: String,
    enum: ['success', 'failed', 'in_progress'],
    default: 'success'
  },
  metadata: {
    controlsMonitored: { type: Number, default: 0 },
    issuesFound: { type: Number, default: 0 },
    lastError: { type: String }
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Integration', integrationSchema);