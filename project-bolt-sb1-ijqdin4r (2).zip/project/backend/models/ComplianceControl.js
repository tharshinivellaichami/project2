const mongoose = require('mongoose');

const complianceControlSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.ObjectId,
    ref: 'User',
    required: true
  },
  controlId: {
    type: String,
    required: true
  },
  framework: {
    type: String,
    enum: ['SOC2', 'ISO27001', 'HIPAA', 'GDPR'],
    required: true
  },
  category: {
    type: String,
    required: true
  },
  name: {
    type: String,
    required: true
  },
  description: {
    type: String,
    required: true
  },
  status: {
    type: String,
    enum: ['passed', 'warning', 'critical', 'not_applicable'],
    default: 'warning'
  },
  score: {
    type: Number,
    min: 0,
    max: 100,
    default: 0
  },
  lastAssessed: {
    type: Date,
    default: Date.now
  },
  evidence: [{
    type: {
      type: String,
      enum: ['document', 'screenshot', 'log', 'configuration']
    },
    source: String,
    data: mongoose.Schema.Types.Mixed,
    timestamp: { type: Date, default: Date.now }
  }],
  issues: [{
    severity: {
      type: String,
      enum: ['low', 'medium', 'high', 'critical']
    },
    description: String,
    remediation: String,
    status: {
      type: String,
      enum: ['open', 'in_progress', 'resolved'],
      default: 'open'
    },
    createdAt: { type: Date, default: Date.now }
  }],
  automatedChecks: {
    enabled: { type: Boolean, default: true },
    frequency: {
      type: String,
      enum: ['daily', 'weekly', 'monthly'],
      default: 'weekly'
    },
    lastRun: Date,
    nextRun: Date
  }
}, {
  timestamps: true
});

// Index for efficient queries
complianceControlSchema.index({ user: 1, framework: 1, status: 1 });
complianceControlSchema.index({ user: 1, controlId: 1 }, { unique: true });

module.exports = mongoose.model('ComplianceControl', complianceControlSchema);